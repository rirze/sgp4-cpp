/*       ----------------------------------------------------------------
*
*                              DTMcom.cpp
*
*  this file contains common, utililty, and IO routines for the dtm model.
*
*       (w) 719-573-2600, email dvallado@agi.com
*
*     current :
*                6 aug 13  david vallado
*                            conversion to c ++ 
*     changes :
*               10 may 13  sean bruinsma
*                            original baseline
*     *****************************************************************       */


#include "StdAfx.h"

#include "DTMcom.h"


 //---------------------------------------------------------------------------
 //
 // FUNCTION: a2K
 //
 //> @brief   This function gets K from a, based on the "tramkm.f" subroutine
 //>
 //> @authors Sean Bruinsma
 //>          Raul Dominguez
 //
 // INPUT ARGUMENTS:   int a            => "a" index
 //>                   @param[in] a a index value
 //
 // OUTPUT ARGUMENTS:  double a2K           <= "K" index corresponding to "a"
 //
 // REVISION HISTORY:
 //
 //  @version 1.0
 //  @date 09/08/2012
 //  Upgraded from FORTRAN 77 code
 //
 //  @version 1.1
 //  @date 14/09/2011
 //  Change output from double to real
 //
 //  @version 1.2
 //  @date 20/09/2011
 //  Check input "a" value. If it is less than 0, fatal error
 //
 //> @version 1.3
 //> @date 01/10/2011
 //  Changed input type. Now the routine accepts a real number (instead of
 //  an int)
 //---------------------------------------------------------------------------
 
double a2K
	(  double a  )
	{
        //Conversion tables
        int table_length;
        table_length = 28;
		// cdav
		double temp;

        double AM[29] = { 0.0,   0.0,   1.4,   3.4,   5.4,   7.4,  10.4,  13.4,  
                         16.4,  20.4,  26.4,  33.4,  40.4,  50.4,  60.4,  70.4,   
                         86.4, 103.4, 120.4, 146.4, 173.4, 200.4, 243.4, 286.4, 
						330.4, 386.4, 443.4, 500.4, 611.4};

        double AKM[29] = {0.0,   0.0,   0.33,  0.66,  1.0,   1.33,  1.66,  2.0,
			              2.33,  2.66,  3.0,   3.33,  3.66,  4.0,   4.33,  4.66,  
						  5.0,   5.33,  5.66,  6.0,   6.33,  6.66,  7.0,   7.33,  
						  7.66,  8.0,   8.33,  8.66,  9.0};
        //Auxiliaries
        int i, im;

		//if a is less than 0, return an error
        if (a < 0.0) 
    		fatal_error(11);

        temp = -1.0;
        for (i=1; i <=table_length; i++)
		{
              if(a == AM[i]) 
                  return temp = AKM[i];
              else if (a <= AM[i]) 
			  {
				  im = i - 1;
                  return temp = AKM[im] + (AKM[i] - AKM[im]) * (a - AM[im]) / (AM[i] - AM[im]);
			  }
		}  // for

         if (temp < 0.0) 
            fatal_error(12);
         return temp;
	 }  // function a2k


 //---------------------------------------------------------------------------
 //
 // FUNCTION: local_solar_time
 //
 //> @brief  find the local solar time in radians given the universal time and
 //>              the longitude
 //
 //> @details This function computes the local solar time in radians from the
 //>          universal time and the longitude, by means of the formula
 //>         @f$LST =2\cdot \pi ( nsec/3600 + \lambda \cdot (24/3600) )@f$
 //>           this function assumes then that local solar time
 //>           ranges from 0 to 2pi.
 //>           It also sanitizes output, so angles out of the 0 to 2pi range
 //>           are converted to the 0-2pi interval
 //
 //> @author Raul Dominguez
 //
 // INPUT ARGUMENTS:
 //>                    @param[in]  longitude  longitude in degress
 //>                    @param[in]   hour      universal time (hour)
 //>                    @param[in]   minute    universal time (minute)
 //>                    @param[in]   sec       universal time (seconds)
 //>
 // OUTPUT ARGUMENTS:
 //>                    @param[out]  local_solar_time  local solar time in radians
 //
 // REVISION HISTORY:
 //
 // version 1.0
 // date 31/07/2012
 // Initial version
 //
 // version 1.1
 // date 11/09/2012
 // Sanitize output, so that it is between 0 and two pi
 //
 //> @version 1.2
 //> @date 14/09/2012
 //> Change in/out from double to real
 //
 //---------------------------------------------------------------------------
 
double local_solar_time 
	  (
	     double longitude, int hour, int minute, double sec
	  )
 {
   //auxiliaries
   double nsec, temp, pi;

   pi = 3.14159265358979323846;
 
   //compute the number of seconds elapsed since start of the day
   //note that seconds are double precision
   nsec = hour * 3600.0 + minute * 60.0 + sec;

   //compute the local solar time
   temp = (2.0 * pi/(24.0)) * ((nsec/3600.0) + (longitude/15.0));

   //sanitize the output
   if (temp > 2.0 * pi) 
   {
       while (temp > 2.0 * pi)
          temp = temp-2.0 * pi;
   }
   else if (temp < 0.0) 
   {
       while (temp < 0.0)
          temp = temp + 2.0 * pi;
   }
   return temp;

} // function localsolartime





 //---------------------------------------------------------------------------
 //
 // FUNCTION: leap day
 //
 //> @brief returns a 1 if the input year is a leap year and 0 otherwise
 //
 //> @author Raul Dominguez
 //
 // INPUT ARGUMENTS:   int year         => year
 //
 // OUTPUT ARGUMENTS:  int leap_day     <= 1 if the year is leap year, 0 otherwise
 //
 // REVISION HISTORY: 31/07/2012 Initial version
 //
 //---------------------------------------------------------------------------
 int leap_day
	 (int year)
   {
	 if ((year % 400) == 0) 
         return 1;
     else if ((year % 100) == 0) 
         return 0;
     else if ((year % 4) == 0) 
         return 1;
     else
         return 0;
   }    // function leap_day

   

 //---------------------------------------------------------------------------
 //
 // FUNCTION: linear_interpolation
 //
 //> @brief perform a linear interpolation between (x1,y1) and (x2,y2)
 //
 //> @author Raul Dominguez
 //
 // INPUT ARGUMENTS:   real x1,y1,x2,y2,x => data vectors (x1,y1), (x2,y2) and
 //                                            point x in which we interpolate
 //
 // OUTPUT ARGUMENTS:  real linear_interpolation <= value of the interpolated
 //                                                   line at x
 //
 // REVISION HISTORY: 31/07/2012 Initial version
 //                   14/09/2012 Changed i/o from double to real
 //
 //---------------------------------------------------------------------------
 double linear_interpolation 
      (
	    double x1, double y1, double x2, double y2, double x 
      )
	{
		double a, b;

        a = (y1 - y2) / (x1 - x2);
        b = y1 - (a * x1);

        return a * x + b;

      //write(*,*) "interpolation:"
      //write(*,*) "X              Y"
      //write(*,*) x1,y1
      //write(*,*) x2,y2
      //write(*,*) "punto", x
      //write(*,*) "resultado", linear_interpolation
      //write(*,*)  " "
	}  // function linear_interpolation


 //---------------------------------------------------------------------------
 //
 // FUNCTION: hms2hr
 //
 //> @brief  convert a time from hours, minutes and seconds to hours (decimal)
 //
 //> @author Raul Dominguez
 //
 // INPUT ARGUMENTS:   int hr            => hours
 //                    int mins          => minutes
 //                    double  sec           => seconds
 //
 // OUTPUT ARGUMENTS:  double  hms2hr        <= decimal number of hours corresponding
 //                                             to the input
 //
 // REVISION HISTORY: 31/07/2012 Initial version
 //                   14/09/2012 Convert output from double to real
 //
 //---------------------------------------------------------------------------

 double hms2hr 
     (
	   int hr, int mins, double sec 
	 )
	{
		return hr + mins/60.0 + sec/3600.0;
	}  // function hms2hr



 //---------------------------------------------------------------------------
 //
 // FUNCTION: day_of_year
 //
 //> @brief this function returns the number of days elapsed since the beginning of the year
 //>              for a given date. the output ranges from 0 to 365 (or 366 days in leap years)
 //
 //> @author Raul Dominguez
 //
 //
 // INPUT ARGUMENTS:   int day         => day
 //                    int month       => month
 //                    int year        => year
 //
 // OUTPUT ARGUMENTS:  int day_of_year <= the day of year corresponding to the input date
 //
 // REVISION HISTORY: 31/07/2012 Initial version
 //
 //---------------------------------------------------------------------------
 
int day_of_year
	(
	  int day, int month, int year 
    )
{
   int month_length[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
   int i, temp;

   month_length[2] = 28 + leap_day(year); //count the leap day

   temp=0;
   for (i=1;i <= month-1; i++)
      temp = temp + month_length[i];
   
   return temp + day;

}  // function day_of_year


 //---------------------------------------------------------------------------
 //
 // FUNCTION: mdyhms_ok
 //
 //> @brief This function checks wheter the user has input a valid date or not
 //>         for example, a date like 34/01/2012 is invalid.
 //>         It returns .TRUE. if the input date is ok, and .FALSE. otherwise
 //
 //> @author Raul Dominguez
 //
 // INPUT ARGUMENTS:   int day         => day
 //                    int month       => month
 //                    int year        => year
 //                    int hour        => hour
 //                    int minute      => minute
 //                    double  second      => second
 //
 // OUTPUT ARGUMENTS:  logical mdyhms_ok <= .TRUE. if the user-entered parameters
 //                                                are a proper date. .FALSE.
 //                                                otherwise
 //
 // REVISION HISTORY: 06/09/2012 Initial version
 //
 //---------------------------------------------------------------------------

 bool mdyhms_ok
	 (
	    int day, int month, int year, int hour, int minute,
		double second 
     )
{
   //table with the duration of months
   int month_length[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

   month_length[2] = 28 + leap_day(year); //count the leap day

    //check day and month
    if ((month < 1) || (month > 12)) 
	{
     return false;
	}

    if ((day < 1) || (day > month_length[month])) 
	{
     return false;
	}

    if ((hour < 0) || (hour > 24)) 
	{
     return false;
	}

    if ((minute < 0) || (minute > 59)) 
	{
     return false;
	}

    if ((second < 0.0) || (second >= 60.0)) 
	{
     return false;
	}

    return true;

} // function mdyhms_ok

	 
 //---------------------------------------------------------------------------
 //
 // SUBROUTINE: DJ2000
 //
 //> @brief COMPUTES CALENDER DATE FROM MODIFIED JULIAN DAY 2000
 //>              VALID FOR DATES BETWEEN 1950/JAN/1 AND 2099/DEC/31.
 //>              MJD(2000) = MJD(1950) - 18262.0 IS = 0 ON 2000/01/01 AT 00:00:00.
 //
 //> @author legacy code
 //
 // INPUT ARGUMENTS:   (double) DAY    =>    MOD. JULIAN DAY, REFERRED TO 2000 (MAY BE NEGATIVE).
 //
 // OUTPUT ARGUMENTS:  (intS)      <=    I=YEAR, J=MONTH, K=DAY, JHR=HOUR, MI=MINUTE
 //                    (double)        <=    SEC=SECOND.
 //
 // REVISION HISTORY: legacy code
 //
 //---------------------------------------------------------------------------
 void DJ2000
	  ( 
	    double MJDay, int& year, int& mon, int& day, int& hr, int& minute, double& sec
	  )
 {
      double JDAY;
	  int L, M, N, JJ;
//  MAKE SURE TO ROUND-OFF ONLY DOWN, ALSO FOR NEGATIVE MJD:
      JDAY = MJDay + 18262.0;
      L = floor((4000.0 * (JDAY + 18204))/1461001);
      N = JDAY - floor((1461.0 * L)/4) + 18234;
      M = floor((80.0 * N)/2447);
      day = N - floor((2447.0 * M)/80);
      JJ  = (int)floor(M/11.0);
      mon  = M + 2 - 12*JJ;
      year = 1900 + L + JJ;
      sec = (MJDay - (JDAY-18262)) * 24.0;
      hr  = (int)floor(sec);
      sec = (sec - (hr)) * 60.0;
      minute = (int)floor(sec);
      sec = (sec - (minute)) * 60.0;
 } // function DJ2000




 //---------------------------------------------------------------------------
 //
 // SUBROUTINE: JD2000
 //
 //> @brief GIVES THE NEW MOD. JULIAN DAY (MJD=0.0 ON 2000/JAN/1 AT 0:00:00)
 //>        FOR INPUT CALENDAR DATES BETWEEN 1950/JAN/1 AND 2099/DEC/31..
 //>
 //>    MJD(2000) = MJD(1950) - 18262.0
 //
 //> @author legacy code
 //
 // OUTPUT ARGUMENTS:   (double) DAY    =>    MOD. JULIAN DAY, REFERRED TO 2000 (MAY BE NEGATIVE).
 //
 // INPUT ARGUMENTS:  (intS)      <=    I=YEAR, J=MONTH, K=DAY, JHR=HOUR, MI=MINUTE
 //                    (double)        <=    SEC=SECOND.
 //
 // REVISION HISTORY: legacy code
 //
 //---------------------------------------------------------------------------

 void JD2000
	 (
	   double& MJDay, int year, int mon, int day, int hr, int minute, double sec
     )
{
     double JJ;
     int L;
     // note floor returns double rounded towards zero, need to recast if int is needed, 
	 // and args must have a double in them
	 JJ  = floor((14.0 - mon)/12);
     L   = year - JJ - 1900 * (int)floor(year/1900.0) + 100 * (int)floor(2000.0/(year + 1951));
     MJDay = day - 36496 + floor((1461.0 * L)/4) + floor((367.0 * (mon - 2 + JJ * 12))/12);
     MJDay = MJDay + (((hr * 60 + minute) * 60) + sec) / 86400.0;
} // function JD2000



 //---------------------------------------------------------------------------
 //
 // SUBROUTINE: fatal error
 //
 //> @brief this routine comes into focus when a fatal error happens in
 //>              dtm_wrap module. The user should modify this routine
 //>              to fit into his/her error handling scheme
 //
 //> @author Raul Dominguez
 //
 // INPUT ARGUMENTS:   int code         => error code
 //
 // REVISION HISTORY: 31/07/2012 Initial version
 //
 //---------------------------------------------------------------------------
 
void fatal_error 
    (
	    int code
	)
{
    typedef char ls[120];
	ls error_messages[20];

    //these messages tell the user what happened
    strcpy(error_messages[1] ,"Cannot read 'f' from fluxes array. Dates in file do not match user input date");
    strcpy(error_messages[2] ,"Cannot read 'a' from geomagnetic data array. Dates in file do not match user input date");
    strcpy(error_messages[3] ,"Cannot open solar proxies file");
    strcpy(error_messages[4] ,"I/O error while reading solar proxies file");
    strcpy(error_messages[5] ,"Solar proxies file longer than max_lines parameter");
    strcpy(error_messages[6] ,"Cannot open geomagnetic proxies file");
    strcpy(error_messages[7] ,"I/O error while reading geomagnetic proxies file");
    strcpy(error_messages[8] ,"Geomagnetic proxies file longer than max_lines parameter");
    strcpy(error_messages[9] ,"Geomagnetic proxies file too new. The first record of this file must be 48 hrs or more before the date");
    strcpy(error_messages[10],"The provided calendar date is invalid. Please check it");
    strcpy(error_messages[11],"Geomagnetic proxy (am) file contains an invalid measurement. Check geomagnetic proxies file");
    strcpy(error_messages[12],"Geomagnetic proxy (am) has a strange value (too big). Check geomagnetic proxies file");

    printf( "FATAL ERROR in dtm_wrap module %i \n", error_messages[code] );
} // end fatal_error


 //---------------------------------------------------------------------------
 //
 // SUBROUTINE: warning
 //
 //> @brief this routine comes into focus when a non-fatal error happens in
 //>              dtm_wrap module. These errors, altough non fatal, should
 //>              be reported to the final user. The user should modify this routine
 //>              to fit into his/her error handling scheme
 //
 //> @author  Raul Dominguez
 //
 // INPUT ARGUMENTS:   int code         => error code
 //
 // REVISION HISTORY: 31/07/2012 Initial version
 //
 //---------------------------------------------------------------------------
void warning 
    ( 
	    int code
    )
{
    typedef char ls[100];
	ls warning_messages[20];

    //these messages tell the user what happened
    strcpy(warning_messages[1], " "); // Unused
    strcpy(warning_messages[2], "Unable to interpolate fbar. Returning a non-interpolated value");

    printf( "\n\n---------------------------------- \n" );
    printf( "WARNING in dtm_wrap module\n" );
    printf( "%i", warning_messages[code] );
    printf( "-----------------------------------" );
} // function warning


 //---------------------------------------------------------------------------
 //
 // SUBROUTINE: process_input_date
 //
 //> @brief this routine fills the data in the provided in_date structure
 //>
 //> @details If the user-input date is in MJD2000, fill the fields containing
 //>          day month year hour minute seconds. If the user provided d-m-yr
 //>          h-m-s, fill the MJD2000 field
 //
 //> @author  Raul Dominguez
 //
 // INPUT ARGUMENTS:
 //                   @param[inout] in_date structure whose fields are to be filled
 //
 // REVISION HISTORY: 14/09/2012 Initial version
 //
 //---------------------------------------------------------------------------

void process_input_date 
	( 
	    dtm_daterectype& in_date
    )
{
    if (in_date.type_flag == 1) 
	{
         //Convert the user entered date to dd/mm/year hh:mm:ss.sssss
         DJ2000(in_date.mjd2000,in_date.year,in_date.month,in_date.day, 
                in_date.hour,in_date.minute,in_date.second);
	}
    else if (in_date.type_flag == 2) 
	{
        //the user gave an universal time in d-m-yr h-m-s format

        //First check that the input date is OK
        if (mdyhms_ok(in_date.day, in_date.month, in_date.year, in_date.hour, 
            in_date.minute, in_date.second) == false) 
		{
            fatal_error(10);
    	} 

        //also convert ymdhms to mjd2000
        JD2000(in_date.mjd2000, in_date.year, in_date.month, in_date.day, 
               in_date.hour, in_date.minute, in_date.second);
	}

} // function process_input_date



 //
 // initialize Space Weather
 // this routine simply opens and reads the geomagnetic and solar flux data
 //
void InitSPW
    (
	  char path_to_a_file[100], char path_to_f_file[100], int& number_of_lines_in_a_file,
      int& number_of_lines_in_f_file, a_structtype a_indexes[3000], f_structtype f_indexes[3000]
    )
{
	  char longstr1[140];
	  FILE *infile;
      //Counter indexes
      int file_io_status;
      int idx;
	  long int max_lines;
	  char temp[8], temp4[4], temp4a[8], temp4b[4], temp20[20];
	  //save first_run,a_indexes,f_indexes, number_of_lines_in_a_file, number_of_lines_in_f_file;

	  //======================================================================
	  max_lines = 3000;

	  strcpy( path_to_a_file,"");
      strcpy( path_to_a_file,"d:/Codes/DTM/dtmsrc/data/am_file_spiderx.dat");  // geomagnetic indices
      strcpy( path_to_f_file,"");
      strcpy( path_to_f_file,"d:/Codes/DTM/dtmsrc/data/proxies_unadjustedx.dat");  // solar flux values

      //This block reads the "f" file
      file_io_status = 0;

	  infile  = fopen( path_to_f_file, "r");
      // open (f_file_unit,file=path_to_f_file,iostat=file_io_status,status='old')

      if (infile == NULL)
	  {
	      printf("Failed to open file: %s\n", path_to_f_file);
//          exit;
      }

      //skip first 14 lines (header)
      for (idx=1; idx <=14; idx++)
		 fgets( longstr1,130,infile);

      //  read (f_file_unit,'(a1)') dummychar;
      idx=1;
	  while (feof(infile) == 0)
      {
          fgets( longstr1,130,infile);
          //3x,i4,3x,i2,3x,i2,3x,4x,3x,f4.0,3x,f4.0,3x,4x      
		  // %[^_] means to read until an underscore character is encountered
	  	  // use dummy string to bypass NaN's
		  sscanf(longstr1," %i %i %i %8s %lf %lf ", &f_indexes[idx].year, &f_indexes[idx].month, &f_indexes[idx].day, 
				                                 &temp, &f_indexes[idx].f, &f_indexes[idx].fbar );
		  idx = idx + 1;

          //stop the routine if the file contains more lines than the max_lines parameter
          if (idx > max_lines) 
		  {
		      fatal_error(5);
//		      exit;
		  }
      }    // (strcmp(longstr1, "#")!=0) && 

		  number_of_lines_in_f_file = idx - 1;
          fclose(infile);

          //This block reads the "a" file
          file_io_status = 0;
          
		  // cdav read in geomagnetic indices
		  infile  = fopen( path_to_a_file, "r");
          //	open (a_file_unit,file=path_to_a_file,iostat=file_io_status,status='old')

          if (infile == NULL)
	      {
	          printf("Failed to open file: %s\n", path_to_f_file);
//              exit;
          }
        
          idx=1;
          while (feof(infile) == 0)
  		  {
			  fgets( longstr1,130,infile);
              //               4i4,4x,9i4   cdav chg to dayofyear
              // use d format for integers with leading 0's
			  // sscanf doesn't appear to be able to parse strings "and" values, so extract all values with atoi, then do
			  // substrings
			  sscanf(longstr1,"%20c %4i %4i %4i %4i %4i %4i %4i %4i %4i ", &temp20,
    	                         &a_indexes[idx].mean_am, &a_indexes[idx].am[1], &a_indexes[idx].am[2], &a_indexes[idx].am[3], 
								 &a_indexes[idx].am[4], &a_indexes[idx].am[5], &a_indexes[idx].am[6], &a_indexes[idx].am[7], 
							     &a_indexes[idx].am[8]);
              strncpy(temp4,&longstr1[0],4);  // get substring value
              strncpy(temp4a,&longstr1[4],4);
              strncpy(temp4b,&longstr1[8],4);
			  a_indexes[idx].month = atoi(temp4);
			  a_indexes[idx].day = atoi(temp4a);
			  a_indexes[idx].year = atoi(temp4b);
//			  a_indexes[idx].day = int(j/10000);
//			  a_indexes[idx].year = j- a_indexes[idx].day * 10000;
//			  a_indexes[idx].dayofyear =  int(k/10000);

              idx = idx + 1;
		
              //stop the routine if the file contains more lines than the max_lines parameter
              if (idx > max_lines) 
			  { 
                  fatal_error(8);
//				  exit;
			  }
	  	  } //  end while

		  number_of_lines_in_a_file = idx - 1;
		  
          fclose(infile);

}  // function InitSPW


// http://www.daniweb.com/software-development/c/threads/395169/converting-string-to-float-without-atof-for-scientific-notation
// c++ is lousy at strings!!
void ScientificToDouble(char *in_String, double& tepom) 
{
	// Loop Variables
	int        Counter       = 0;
	int        Length        = strlen(in_String) + 1;
	// Flags and signs
	int        NegativeFlag  = 0;
	int        DecimalFlag   = 0;
	int        ExponentSign  = 0;  // -1 = Negative, 0 = None, 1 = Positive
	// Numerical Data
	int        Exponent      = 0;
	int        FinalDivision = 1;
	long       Digits        = 0;
//	double tepom;

	// Loop per each character. Ignore anything weird.
	for (;Counter < Length; Counter++) 
	{
		// Depending on the current character
		switch (in_String[Counter]) 
		{
			// On any digit
			case '0': case '5':
			case '1': case '6':
			case '2': case '7':
			case '3': case '8':
			case '4': case '9':
				// If we haven't reached an exponent yet ("e")
				if (ExponentSign == 0) 
				{
					// Adjust the final division if a decimal was encountered
					if (DecimalFlag) FinalDivision *= 10;
					// Add a digit to our main number
					Digits = (Digits * 10) + (in_String[Counter] - '0');
				// If we passed an "e" at some point
				} else 
				{
					// Add a digit to our exponent
					Exponent = (Exponent * 10) + (in_String[Counter] - '0');
				}
				break;
			// On a negative sign
			case '-':
				// If we passed an 'e'
				if (ExponentSign > 0)
					// The exponent sign will be negative
					ExponentSign = -1;
				// Otherwise we are still dealing with the main number
				else
					// Set the negative flag. We will negate the main number later.
					NegativeFlag = 1;
				break;
			// If we encounter some kind of "e"
			case 'e': case 'E':
				// Set the exponent flag
				ExponentSign = 1;
				break;
			// If we encounter a period
			case '.':
				// Set the decimal flag. We will start tracking decimal depth.
				DecimalFlag = 1;
				break;
			// We gladly accept all sorts of additional garbage.
			default:
				break;
		}
	}
	// If the negative flag is set, negate the main number
	if (NegativeFlag)
		Digits = 0 - Digits;
	
	// If the exponent is supposed to be negative, negate it now
	if (ExponentSign < 0)
		Exponent = 0 - Exponent;
	// Return the calculated result of our observations
	tepom = double(Digits)/double(FinalDivision) * double(pow(10.0, Exponent));
	//return tepom;
}  // function ScientificToDouble


//---------------------------------------------------------------------------
//
// ROUTINE: DTMInit
//
//> @author Sean Bruinsma
//>
//> @brief  read DTM format/version 2012
//
// PROTOTYPE:
//                 P_ReadDTM12 (
//                             )
//
//
// INPUT ARGUMENTS:
//
//
// OUTPUT ARGUMENTS:
//
//> @date 03/2012
//
//
// * rol Programme: read DTM format/version 2012 
//
//      pgf90  -o P_ReadDTM12.x P_ReadDTM12.f90
//
// * vers      : 03/2012
// * aut      : PS
//
//---------------------------------------------------------------------------

void DTMInit
	(
	  char PATH_TO_DEN_UNC_1[100], char PATH_TO_DEN_UNC_2[100], char PATH_TO_DEN_UNC_3[100],
	  char PATH_TO_DTM2012_IN_FILE[100], char PATH_TO_DTM2012_OUT_FILE[100], int IVERIF,
      double nomgrid[25][19], double kp_scale[25][19], double alt_scale[25][19],
	  pardtmtype& pardtm
	)
{ 
    // int IVERIF = 0;  //// IVERIF = 0/1 >> print model in u_Out
    // _._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._.
    //.. VARIABLES .. 
	dtmindextype dtmindex;  // needed because numbers weren't passing correctly
	int  i, j, j_test, npdtm;
    int  Iok;
    char titre[100], ctp120[8], Com[210];
  
    FILE *infile, *outfile;
    char longstr1[5200];
    FILE *infile1, *infile2, *infile3;
    double tempo;
    char tempstr[11];
    char infilename[100];
  
  // --------------------------------------------------
    strcpy( infilename, PATH_TO_DEN_UNC_1);
    infile1 = fopen(infilename, "r");  // files with all 432 values on 1 line
    if (infile1 == NULL)
	    printf("Failed to open file: %s\n", infilename);

	strcpy(infilename, PATH_TO_DEN_UNC_2);
    infile2 = fopen(infilename, "r");  // files with all 432 values on 1 line
    if (infile2 == NULL)
	    printf("Failed to open file: %s\n", infilename);

	strcpy(infilename, PATH_TO_DEN_UNC_3);
    infile3 = fopen(infilename, "r");  // files with all 432 values on 1 line
    if (infile3 == NULL)
	    printf("Failed to open file: %s\n", infilename);

    // cdav may need to shift each by 1...
    // do a slow but works way. The msvs2010 debugger shows the values incorrect, 
    // but correct AFTER the call
	fgets( longstr1,5200,infile1);  // single line 5185 char
	for (j=0; j <18; j++)
    {
    	for (i=0; i <24; i++)
        {
            strncpy(tempstr, &longstr1[j*276+(i+j)*12],11); // starts at 0
            tempstr[11] = '\0';  // each variable is just 11 chars long. put endofstr marker AT 11
            ScientificToDouble(tempstr, tempo);
            nomgrid[i+1][j+1] = tempo;
	    }  // through i
    }  // through j

	fgets( longstr1,5200,infile2);  // single line 5185 char
	for (j=0; j <18; j++)
    {
    	for (i=0; i <24; i++)
        {
            strncpy(tempstr, &longstr1[j*276+(i+j)*12],11); // starts at 0
            tempstr[11] = '\0';  // each variable is just 11 chars long. put endofstr marker AT 11
            ScientificToDouble(tempstr, tempo);
            kp_scale[i+1][j+1] = tempo;
	    }  // through i
    }  // through j

	fgets( longstr1,5200,infile3);  // single line 5185 char
	for (j=0; j <18; j++)
    {
    	for (i=0; i <24; i++)
        {
            strncpy(tempstr, &longstr1[j*276+(i+j)*12],11); // starts at 0
            tempstr[11] = '\0';  // each variable is just 11 chars long. put endofstr marker AT 11
            ScientificToDouble(tempstr, tempo);
            alt_scale[i+1][j+1] = tempo;
    	}  // through i
    }  // through j

//		fgets( longstr1,5200,infile3);  // single line 5185 char
//		sscanf(longstr1,"%{%g} ", &alt_scale );

    fclose (infile1);
    fclose (infile2);
    fclose (infile3);

    infile  = fopen( PATH_TO_DTM2012_IN_FILE, "r");
   
    if (IVERIF == 1) 
        outfile  = fopen( PATH_TO_DTM2012_OUT_FILE, "w");

    // --------------------------------------------------
    fgets( longstr1,110,infile);
    strcpy(titre, longstr1);
	//scanf( "%s",&titre );
    fgets( longstr1,210,infile);
    sscanf( longstr1,"%i",&npdtm );

    //	  fgets( longstr1,210,infile); re-process the line
    strcpy(Com, longstr1);
    //      scanf( "%s",&Com );
    //      backspace(u_In);

    if (IVERIF == 1) 
    {
        fprintf(outfile, "%110s \n", titre);
        fprintf(outfile, "%200s \n",  Com);
	    printf( "%110s \n",titre);
        printf( "%210s \n", Com);
    }

    // --------------------------------------------------
    Iok = 1;    // test read ok/nok
     
    // ...... termes ONE
    i = 1;
    fgets( longstr1,210,infile);
	sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
		           &j_test,  &pardtm.tt.T_one  ,&pardtm.dtt.T_one, 
                   &pardtm.h.T_one   ,&pardtm.dh.T_one, &pardtm.he.T_one  ,&pardtm.dhe.T_one, 
                   &pardtm.ox.T_one  ,&pardtm.dox.T_one, &pardtm.az2.T_one ,&pardtm.daz2.T_one, 
                   &pardtm.o2.T_one  ,&pardtm.do2.T_one, &pardtm.az.T_one  ,&pardtm.daz.T_one, 
                   &pardtm.t0.T_one  ,&pardtm.dt0.T_one, &pardtm.tp.T_one  ,&pardtm.dtp.T_one);

	//// ..:
     if (i != j_test) 
     {
         printf( " * * * WARNING: PB in field T_one " );
         printf( " * * * WARNING: incompatibility between dimension T_lat & DTM file  " );
         printf( " * * *  i = %6i j_test = %6i ", i, j_test);
         Iok = 0; 
         goto fifteen;
	 }


// ...... termes in LAT
	 // cdav lat all these also have to be < and not <= because the array dimension is 1 more
    for (i = 1; i <  dtmindex.Nb_lat; i++ )
 	{
        ////    READ(u_In,640) i,(DTM_12(j).T_lat[i],ddtm_12(j).T_lat[i],j = 1,9)
        fgets( longstr1,210,infile);
	    sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_lat[i]  ,&pardtm.dtt.T_lat[i], 
                  &pardtm.h.T_lat[i]   ,&pardtm.dh.T_lat[i], &pardtm.he.T_lat[i]  ,&pardtm.dhe.T_lat[i], 
                  &pardtm.ox.T_lat[i]  ,&pardtm.dox.T_lat[i], &pardtm.az2.T_lat[i] ,&pardtm.daz2.T_lat[i], 
                  &pardtm.o2.T_lat[i]  ,&pardtm.do2.T_lat[i], &pardtm.az.T_lat[i]  ,&pardtm.daz.T_lat[i], 
                  &pardtm.t0.T_lat[i]  ,&pardtm.dt0.T_lat[i], &pardtm.tp.T_lat[i]  ,&pardtm.dtp.T_lat[i]);
        if (i != j_test) 
          {
             printf( " * * * WARNING: PB in field T_lat " );
             printf(  " * * * WARNING: incompatibility between dimension T_lat & DTM file  " );
             printf( " * * *  i = %6i j_test = %6i ", i, j_test);
             Iok = 0;
             goto fifteen;
          }
 	}

// --------------------------------------------------
// ...... termes in Flux
	// cdav flux
    for (i = 1; i <  dtmindex.Nb_flux; i++ )
    {
        fgets( longstr1,210,infile);
	    sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_flux[i]  ,&pardtm.dtt.T_flux[i], 
                  &pardtm.h.T_flux[i]   ,&pardtm.dh.T_flux[i], &pardtm.he.T_flux[i]  ,&pardtm.dhe.T_flux[i], 
                  &pardtm.ox.T_flux[i]  ,&pardtm.dox.T_flux[i], &pardtm.az2.T_flux[i] ,&pardtm.daz2.T_flux[i], 
                  &pardtm.o2.T_flux[i]  ,&pardtm.do2.T_flux[i], &pardtm.az.T_flux[i]  ,&pardtm.daz.T_flux[i], 
                  &pardtm.t0.T_flux[i]  ,&pardtm.dt0.T_flux[i], &pardtm.tp.T_flux[i]  ,&pardtm.dtp.T_flux[i] );

         if (i != j_test) 
        	{
               printf( " * * * WARNING: PB in field T_flux " );
               printf( " * * * WARNING: incompatibility between dimension T_flux & DTM file  " );
               printf( " * * *  i = %6i j_test = %6i ", i, j_test);
               Iok = 0; 
               goto fifteen;
            }
	}

// --------------------------------------------------
// ...... termes in kp
    for (i = 1; i <   dtmindex.Nb_kp; i++ )
	{
         fgets( longstr1,210,infile);
	     sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_kp[i]  ,&pardtm.dtt.T_kp[i], 
                  &pardtm.h.T_kp[i]   ,&pardtm.dh.T_kp[i], &pardtm.he.T_kp[i]  ,&pardtm.dhe.T_kp[i], 
                  &pardtm.ox.T_kp[i]  ,&pardtm.dox.T_kp[i], &pardtm.az2.T_kp[i] ,&pardtm.daz2.T_kp[i], 
                  &pardtm.o2.T_kp[i]  ,&pardtm.do2.T_kp[i], &pardtm.az.T_kp[i]  ,&pardtm.daz.T_kp[i], 
                  &pardtm.t0.T_kp[i]  ,&pardtm.dt0.T_kp[i], &pardtm.tp.T_kp[i]  ,&pardtm.dtp.T_kp[i] );
         if (i != j_test) 
	        {
              printf( " * * * WARNING: PB in field T_kp " );
              printf( " * * * WARNING: incompatibility between dimension T_kp & DTM file  " );
              printf( " * * *  i = %6i j_test = %6i ", i, j_test);
              Iok = 0;
              goto fifteen;
            }
	}

// --------------------------------------------------
// ...... termes in SLat
    for (i = 1; i <   dtmindex.Nb_SLat; i++ )
	{   
        fgets( longstr1,210,infile);
	    sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_SLat[i]  ,&pardtm.dtt.T_SLat[i], 
                  &pardtm.h.T_SLat[i]   ,&pardtm.dh.T_SLat[i], &pardtm.he.T_SLat[i]  ,&pardtm.dhe.T_SLat[i], 
                  &pardtm.ox.T_SLat[i]  ,&pardtm.dox.T_SLat[i], &pardtm.az2.T_SLat[i] ,&pardtm.daz2.T_SLat[i], 
                  &pardtm.o2.T_SLat[i]  ,&pardtm.do2.T_SLat[i], &pardtm.az.T_SLat[i]  ,&pardtm.daz.T_SLat[i], 
                  &pardtm.t0.T_SLat[i]  ,&pardtm.dt0.T_SLat[i], &pardtm.tp.T_SLat[i]  ,&pardtm.dtp.T_SLat[i] );
        if (i != j_test) 
	        {
              printf( " * * * WARNING: PB in field T_SLat " );
              printf( " * * * WARNING: incompatibility between dimension T_SLat & DTM file  " );
              printf( " * * *  i = %6i j_test = %6i ", i, j_test);
              Iok = 0; 
              goto fifteen;
            }
	}

// --------------------------------------------------
// ...... termes in SASLat
    for (i = 1; i <   dtmindex.Nb_SASLat; i++ )
	{
        fgets( longstr1,210,infile);
	    sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_SASLat[i]  ,&pardtm.dtt.T_SASLat[i], 
                  &pardtm.h.T_SASLat[i]   ,&pardtm.dh.T_SASLat[i], &pardtm.he.T_SASLat[i]  ,&pardtm.dhe.T_SASLat[i], 
                  &pardtm.ox.T_SASLat[i]  ,&pardtm.dox.T_SASLat[i], &pardtm.az2.T_SASLat[i] ,&pardtm.daz2.T_SASLat[i], 
                  &pardtm.o2.T_SASLat[i]  ,&pardtm.do2.T_SASLat[i], &pardtm.az.T_SASLat[i]  ,&pardtm.daz.T_SASLat[i], 
                  &pardtm.t0.T_SASLat[i]  ,&pardtm.dt0.T_SASLat[i], &pardtm.tp.T_SASLat[i]  ,&pardtm.dtp.T_SASLat[i] );
        if (i != j_test) 
	        {
              printf( " * * * WARNING: PB in field T_SASLat " );
              printf( " * * * WARNING: incompatibility between dimension T_SASLat & DTM file  " );
              printf( " * * *  i = %6i j_test = %6i ", i, j_test);
              Iok = 0;
              goto fifteen;
         }
	}

// --------------------------------------------------
// ...... termes in T_NSLat
    for (i = 1; i <   dtmindex.Nb_NSLat; i++ )   
	{
        fgets( longstr1,210,infile);
	    sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_NSLat[i]  ,&pardtm.dtt.T_NSLat[i], 
                  &pardtm.h.T_NSLat[i]   ,&pardtm.dh.T_NSLat[i], &pardtm.he.T_NSLat[i]  ,&pardtm.dhe.T_NSLat[i], 
                  &pardtm.ox.T_NSLat[i]  ,&pardtm.dox.T_NSLat[i], &pardtm.az2.T_NSLat[i] ,&pardtm.daz2.T_NSLat[i], 
                  &pardtm.o2.T_NSLat[i]  ,&pardtm.do2.T_NSLat[i], &pardtm.az.T_NSLat[i]  ,&pardtm.daz.T_NSLat[i], 
                  &pardtm.t0.T_NSLat[i]  ,&pardtm.dt0.T_NSLat[i], &pardtm.tp.T_NSLat[i]  ,&pardtm.dtp.T_NSLat[i] );
         if (i != j_test) 
	         {
                printf( " * * * WARNING: PB in field T_NSLat " );
                printf( " * * * WARNING: incompatibility between dimension T_NSLat & DTM file  " );
                printf( " * * *  i = %6i j_test = %6i ", i, j_test);
                Iok = 0; 
                goto fifteen;
             }
	}

// --------------------------------------------------
// ...... termes in T_SANSLat 
    for (i = 1; i <   dtmindex.Nb_SANSLat; i++ )   
	{
         fgets( longstr1,210,infile);
	     sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_SANSLat[i]  ,&pardtm.dtt.T_SANSLat[i], 
                  &pardtm.h.T_SANSLat[i]   ,&pardtm.dh.T_SANSLat[i], &pardtm.he.T_SANSLat[i]  ,&pardtm.dhe.T_SANSLat[i], 
                  &pardtm.ox.T_SANSLat[i]  ,&pardtm.dox.T_SANSLat[i], &pardtm.az2.T_SANSLat[i] ,&pardtm.daz2.T_SANSLat[i], 
                  &pardtm.o2.T_SANSLat[i]  ,&pardtm.do2.T_SANSLat[i], &pardtm.az.T_SANSLat[i]  ,&pardtm.daz.T_SANSLat[i], 
                  &pardtm.t0.T_SANSLat[i]  ,&pardtm.dt0.T_SANSLat[i], &pardtm.tp.T_SANSLat[i]  ,&pardtm.dtp.T_SANSLat[i] );
         if (i != j_test) 
	         {
                printf( " * * * WARNING: PB in field T_SANSLat " );
                printf( " * * * WARNING: incompatibility between dimension T_SANSLat & DTM file  " );
                printf( " * * *  i = %6i j_test = %6i ", i, j_test);
                Iok = 0; 
                goto fifteen;
             }
	}

// --------------------------------------------------
// ...... termes in DiAn
    for (i = 1; i <   dtmindex.Nb_DiAn; i++ )   
	{
         fgets( longstr1,210,infile);
	     sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_DiAn[i]  ,&pardtm.dtt.T_DiAn[i], 
                  &pardtm.h.T_DiAn[i]   ,&pardtm.dh.T_DiAn[i], &pardtm.he.T_DiAn[i]  ,&pardtm.dhe.T_DiAn[i], 
                  &pardtm.ox.T_DiAn[i]  ,&pardtm.dox.T_DiAn[i], &pardtm.az2.T_DiAn[i] ,&pardtm.daz2.T_DiAn[i], 
                  &pardtm.o2.T_DiAn[i]  ,&pardtm.do2.T_DiAn[i], &pardtm.az.T_DiAn[i]  ,&pardtm.daz.T_DiAn[i], 
                  &pardtm.t0.T_DiAn[i]  ,&pardtm.dt0.T_DiAn[i], &pardtm.tp.T_DiAn[i]  ,&pardtm.dtp.T_DiAn[i] );

         if (i != j_test) 
	         {
                printf( " * * * WARNING: PB in field T_DiAn " );
                printf( " * * * WARNING: incompatibility between dimension T_DiAn & DTM file  " );
                printf( " * * *  i = %6i j_test = %6i ", i, j_test);
                Iok = 0; 
                goto fifteen;
               }
	}

// --------------------------------------------------
// ...... termes  SDiAn
    for (i = 1; i <   dtmindex.Nb_SDiAn; i++ )
	{
         fgets( longstr1,210,infile);
	     sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_SDiAn[i]  ,&pardtm.dtt.T_SDiAn[i], 
                  &pardtm.h.T_SDiAn[i]   ,&pardtm.dh.T_SDiAn[i], &pardtm.he.T_SDiAn[i]  ,&pardtm.dhe.T_SDiAn[i], 
                  &pardtm.ox.T_SDiAn[i]  ,&pardtm.dox.T_SDiAn[i], &pardtm.az2.T_SDiAn[i] ,&pardtm.daz2.T_SDiAn[i], 
                  &pardtm.o2.T_SDiAn[i]  ,&pardtm.do2.T_SDiAn[i], &pardtm.az.T_SDiAn[i]  ,&pardtm.daz.T_SDiAn[i], 
                  &pardtm.t0.T_SDiAn[i]  ,&pardtm.dt0.T_SDiAn[i], &pardtm.tp.T_SDiAn[i]  ,&pardtm.dtp.T_SDiAn[i] );
         if (i != j_test) 
	         {
                printf(" * * * WARNING: PB in field T_SDiAn " );
                printf(" * * * WARNING: incompatibility between dimension T_SDiAn & DTM file  " );
                printf( " * * *  i = %6i j_test = %6i ", i, j_test);
                Iok = 0; 
                goto fifteen;
               }
	}

// ------------- -------------------------------------
// ...... termes in  TDi
    for (i = 1; i <   dtmindex.Nb_TDi; i++ )
	{
         fgets( longstr1,210,infile);
	     sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_TDi[i]  ,&pardtm.dtt.T_TDi[i], 
                  &pardtm.h.T_TDi[i]   ,&pardtm.dh.T_TDi[i], &pardtm.he.T_TDi[i]  ,&pardtm.dhe.T_TDi[i], 
                  &pardtm.ox.T_TDi[i]  ,&pardtm.dox.T_TDi[i], &pardtm.az2.T_TDi[i] ,&pardtm.daz2.T_TDi[i], 
                  &pardtm.o2.T_TDi[i]  ,&pardtm.do2.T_TDi[i], &pardtm.az.T_TDi[i]  ,&pardtm.daz.T_TDi[i], 
                  &pardtm.t0.T_TDi[i]  ,&pardtm.dt0.T_TDi[i], &pardtm.tp.T_TDi[i]  ,&pardtm.dtp.T_TDi[i] );
          if (i != j_test) 
	         {
                printf(" * * * WARNING: PB in field T_TDi " );
                printf( " * * * WARNING: incompatibility between dimension T_TDi & DTM file  " );
                printf( " * * *  i = %6i j_test = %6i ", i, j_test);
                Iok = 0; 
                goto fifteen;
              }
	}

// --------------------------------------------------
// ...... termes in  AMg
    for (i = 1; i <   dtmindex.Nb_AMg; i++ )
	{
        fgets( longstr1,210,infile);
	    sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_AMg[i]  ,&pardtm.dtt.T_AMg[i], 
                  &pardtm.h.T_AMg[i]   ,&pardtm.dh.T_AMg[i], &pardtm.he.T_AMg[i]  ,&pardtm.dhe.T_AMg[i], 
                  &pardtm.ox.T_AMg[i]  ,&pardtm.dox.T_AMg[i], &pardtm.az2.T_AMg[i] ,&pardtm.daz2.T_AMg[i], 
                  &pardtm.o2.T_AMg[i]  ,&pardtm.do2.T_AMg[i], &pardtm.az.T_AMg[i]  ,&pardtm.daz.T_AMg[i], 
                  &pardtm.t0.T_AMg[i]  ,&pardtm.dt0.T_AMg[i], &pardtm.tp.T_AMg[i]  ,&pardtm.dtp.T_AMg[i] );
         if (i != j_test) 
	         {
                printf(" * * * WARNING: PB in field T_AMg \n" );
                printf(" * * * WARNING: incompatibility beetween dimension T_AMg & DTM file  \n" );
                printf( " * * *  i = %6i j_test = %6i \n", i, j_test);
                Iok = 0; 
                goto fifteen;
               }
	}

// --------------------------------------------------
// ...... termes in  Lon
    for (i = 1; i <   dtmindex.Nb_Lon; i++ )
	{
        fgets( longstr1,210,infile);
	    sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_Lon[i]  ,&pardtm.dtt.T_Lon[i], 
                  &pardtm.h.T_Lon[i]   ,&pardtm.dh.T_Lon[i], &pardtm.he.T_Lon[i]  ,&pardtm.dhe.T_Lon[i], 
                  &pardtm.ox.T_Lon[i]  ,&pardtm.dox.T_Lon[i], &pardtm.az2.T_Lon[i] ,&pardtm.daz2.T_Lon[i], 
                  &pardtm.o2.T_Lon[i]  ,&pardtm.do2.T_Lon[i], &pardtm.az.T_Lon[i]  ,&pardtm.daz.T_Lon[i], 
                  &pardtm.t0.T_Lon[i]  ,&pardtm.dt0.T_Lon[i], &pardtm.tp.T_Lon[i]  ,&pardtm.dtp.T_Lon[i] );
         if (i != j_test) 
	         {
                printf(" *** WARNING: PB in field T_Lon \n" );
                printf(" *** WARNING: incompatibility beetween dimension T_Lon & DTM file  \n" );
                printf( " ***  i = %6i j_test = %6i \n", i, j_test);
                Iok = 0; 
                goto fifteen;
               }
	}
//
// ...... termes in dPhas 
    for (i = 1; i <   dtmindex.Nb_dPhas; i++ )
	{
        fgets( longstr1,210,infile);
	    sscanf( longstr1, " %4d %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf %13lf %9lf", 
			      &j_test,  &pardtm.tt.T_dPhas[i]  ,&pardtm.dtt.T_dPhas[i], 
                  &pardtm.h.T_dPhas[i]   ,&pardtm.dh.T_dPhas[i], &pardtm.he.T_dPhas[i]  ,&pardtm.dhe.T_dPhas[i], 
                  &pardtm.ox.T_dPhas[i]  ,&pardtm.dox.T_dPhas[i], &pardtm.az2.T_dPhas[i] ,&pardtm.daz2.T_dPhas[i], 
                  &pardtm.o2.T_dPhas[i]  ,&pardtm.do2.T_dPhas[i], &pardtm.az.T_dPhas[i]  ,&pardtm.daz.T_dPhas[i], 
                  &pardtm.t0.T_dPhas[i]  ,&pardtm.dt0.T_dPhas[i], &pardtm.tp.T_dPhas[i]  ,&pardtm.dtp.T_dPhas[i] );
        if (i != j_test) 
	        {
              printf( " * * * WARNING: PB in field T_dPhas " );
              printf( " * * * WARNING: incompatibility between dimension T_dPhas & DTM file  " );
              printf( " * * *  i = %6i j_test = %6i ", i, j_test);
              Iok = 0; 
              goto fifteen;
            }
	}
// --------------------------------------------------

 
// --------------------------------------------------

// * * * * * * * * * * * * Write / Verify * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * 

 if (IVERIF == 1) 
 {
// ...... termes ONE

     i = 1;
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
			      i, &pardtm.tt.T_one  ,&pardtm.dtt.T_one, 
                  &pardtm.h.T_one   ,&pardtm.dh.T_one,&pardtm.he.T_one  ,&pardtm.dhe.T_one, 
                  &pardtm.ox.T_one  ,&pardtm.dox.T_one,&pardtm.az2.T_one ,&pardtm.daz2.T_one, 
                  &pardtm.o2.T_one  ,&pardtm.do2.T_one, &pardtm.az.T_one  ,&pardtm.daz.T_one, 
                  &pardtm.t0.T_one  ,&pardtm.dt0.T_one, &pardtm.tp.T_one  ,&pardtm.dtp.T_one );

// ...... termes in LAT
	 // cdav lat
    for (i = 1; i <=   dtmindex.Nb_lat; i++ )
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
			 	  i,   &pardtm.tt.T_lat[i]  ,&pardtm.dtt.T_lat[i], &pardtm.h.T_lat[i]   ,&pardtm.dh.T_lat[i], 
                  &pardtm.he.T_lat[i]  ,&pardtm.dhe.T_lat[i],  &pardtm.ox.T_lat[i]  ,&pardtm.dox.T_lat[i], 
                  &pardtm.az2.T_lat[i] ,&pardtm.daz2.T_lat[i], &pardtm.o2.T_lat[i]  ,&pardtm.do2.T_lat[i], 
                  &pardtm.az.T_lat[i]  ,&pardtm.daz.T_lat[i], &pardtm.t0.T_lat[i]  ,&pardtm.dt0.T_lat[i], 
                  &pardtm.tp.T_lat[i]  ,&pardtm.dtp.T_lat[i] );
	}
// ...... termes in Flux
    for (i = 1; i <=   dtmindex.Nb_flux; i++ )   
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
			  	  i,   &pardtm.tt.T_flux[i]  ,&pardtm.dtt.T_flux[i], &pardtm.h.T_flux[i]   ,&pardtm.dh.T_flux[i], 
                  &pardtm.he.T_flux[i]  ,&pardtm.dhe.T_flux[i], &pardtm.ox.T_flux[i]  ,&pardtm.dox.T_flux[i], 
                  &pardtm.az2.T_flux[i] ,&pardtm.daz2.T_flux[i], &pardtm.o2.T_flux[i]  ,&pardtm.do2.T_flux[i], 
                  &pardtm.az.T_flux[i]  ,&pardtm.daz.T_flux[i], &pardtm.t0.T_flux[i]  ,&pardtm.dt0.T_flux[i], 
                  &pardtm.tp.T_flux[i]  ,&pardtm.dtp.T_flux[i] );
	}

// ...... termes in kp
    for (i = 1; i <=   dtmindex.Nb_kp; i++ )   
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
				 i,  &pardtm.tt.T_kp[i]  ,&pardtm.dtt.T_kp[i], &pardtm.h.T_kp[i]   ,&pardtm.dh.T_kp[i], 
                  &pardtm.he.T_kp[i]  ,&pardtm.dhe.T_kp[i], &pardtm.ox.T_kp[i]  ,&pardtm.dox.T_kp[i], 
                  &pardtm.az2.T_kp[i] ,&pardtm.daz2.T_kp[i], &pardtm.o2.T_kp[i]  ,&pardtm.do2.T_kp[i], 
                  &pardtm.az.T_kp[i]  ,&pardtm.daz.T_kp[i], &pardtm.t0.T_kp[i]  ,&pardtm.dt0.T_kp[i], 
                  &pardtm.tp.T_kp[i]  ,&pardtm.dtp.T_kp[i] );
	}
// ...... termes in 
    for (i = 1; i <=   dtmindex.Nb_SLat; i++ )   
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
				 i,  &pardtm.tt.T_SLat[i]  ,&pardtm.dtt.T_SLat[i], &pardtm.h.T_SLat[i]   ,&pardtm.dh.T_SLat[i], 
                  &pardtm.he.T_SLat[i]  ,&pardtm.dhe.T_SLat[i], &pardtm.ox.T_SLat[i]  ,&pardtm.dox.T_SLat[i], 
                  &pardtm.az2.T_SLat[i] ,&pardtm.daz2.T_SLat[i], &pardtm.o2.T_SLat[i]  ,&pardtm.do2.T_SLat[i], 
                  &pardtm.az.T_SLat[i]  ,&pardtm.daz.T_SLat[i], &pardtm.t0.T_SLat[i]  ,&pardtm.dt0.T_SLat[i], 
                  &pardtm.tp.T_SLat[i]  ,&pardtm.dtp.T_SLat[i] );
	}
// ...... termes in 
    for (i = 1; i <=   dtmindex.Nb_SASLat; i++ )
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
				  i,  &pardtm.tt.T_SASLat[i]  ,&pardtm.dtt.T_SASLat[i], &pardtm.h.T_SASLat[i]   ,&pardtm.dh.T_SASLat[i], 
                  &pardtm.he.T_SASLat[i]  ,&pardtm.dhe.T_SASLat[i], &pardtm.ox.T_SASLat[i]  ,&pardtm.dox.T_SASLat[i], 
                  &pardtm.az2.T_SASLat[i] ,&pardtm.daz2.T_SASLat[i], &pardtm.o2.T_SASLat[i]  ,&pardtm.do2.T_SASLat[i], 
                  &pardtm.az.T_SASLat[i]  ,&pardtm.daz.T_SASLat[i], &pardtm.t0.T_SASLat[i]  ,&pardtm.dt0.T_SASLat[i], 
                  &pardtm.tp.T_SASLat[i]  ,&pardtm.dtp.T_SASLat[i] );
	}

// ...... termes in 
    for (i = 1; i <=   dtmindex.Nb_NSLat; i++ )
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
         		  i,  &pardtm.tt.T_NSLat[i]  ,&pardtm.dtt.T_NSLat[i], &pardtm.h.T_NSLat[i]   ,&pardtm.dh.T_NSLat[i], 
                  &pardtm.he.T_NSLat[i]  ,&pardtm.dhe.T_NSLat[i], &pardtm.ox.T_NSLat[i]  ,&pardtm.dox.T_NSLat[i], 
                  &pardtm.az2.T_NSLat[i] ,&pardtm.daz2.T_NSLat[i], &pardtm.o2.T_NSLat[i]  ,&pardtm.do2.T_NSLat[i], 
                  &pardtm.az.T_NSLat[i]  ,&pardtm.daz.T_NSLat[i], &pardtm.t0.T_NSLat[i]  ,&pardtm.dt0.T_NSLat[i], 
                  &pardtm.tp.T_NSLat[i]  ,&pardtm.dtp.T_NSLat[i] );
	}

// ...... termes in 
    for (i = 1; i <=   dtmindex.Nb_SANSLat; i++ )   
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
		 	 	  i,  &pardtm.tt.T_SANSLat[i]  ,&pardtm.dtt.T_SANSLat[i], &pardtm.h.T_SANSLat[i]   ,&pardtm.dh.T_SANSLat[i], 
                  &pardtm.he.T_SANSLat[i]  ,&pardtm.dhe.T_SANSLat[i], &pardtm.ox.T_SANSLat[i]  ,&pardtm.dox.T_SANSLat[i], 
                  &pardtm.az2.T_SANSLat[i] ,&pardtm.daz2.T_SANSLat[i], &pardtm.o2.T_SANSLat[i]  ,&pardtm.do2.T_SANSLat[i], 
                  &pardtm.az.T_SANSLat[i]  ,&pardtm.daz.T_SANSLat[i], &pardtm.t0.T_SANSLat[i]  ,&pardtm.dt0.T_SANSLat[i], 
                  &pardtm.tp.T_SANSLat[i]  ,&pardtm.dtp.T_SANSLat[i] );
	}
// ...... termes in 
    for (i = 1; i <=   dtmindex.Nb_DiAn; i++ )   
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
		 		  i,  &pardtm.tt.T_DiAn[i]  ,&pardtm.dtt.T_DiAn[i], &pardtm.h.T_DiAn[i]   ,&pardtm.dh.T_DiAn[i], 
                  &pardtm.he.T_DiAn[i]  ,&pardtm.dhe.T_DiAn[i], &pardtm.ox.T_DiAn[i]  ,&pardtm.dox.T_DiAn[i], 
                  &pardtm.az2.T_DiAn[i] ,&pardtm.daz2.T_DiAn[i], &pardtm.o2.T_DiAn[i]  ,&pardtm.do2.T_DiAn[i], 
                  &pardtm.az.T_DiAn[i]  ,&pardtm.daz.T_DiAn[i], &pardtm.t0.T_DiAn[i]  ,&pardtm.dt0.T_DiAn[i], 
                  &pardtm.tp.T_DiAn[i]  ,&pardtm.dtp.T_DiAn[i] );
	}
// ...... termes in 
    for (i = 1; i <=   dtmindex.Nb_SDiAn; i++ )
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
		 		  i,  &pardtm.tt.T_SDiAn[i]  ,&pardtm.dtt.T_SDiAn[i], &pardtm.h.T_SDiAn[i]   ,&pardtm.dh.T_SDiAn[i], 
                  &pardtm.he.T_SDiAn[i]  ,&pardtm.dhe.T_SDiAn[i], &pardtm.ox.T_SDiAn[i]  ,&pardtm.dox.T_SDiAn[i], 
                  &pardtm.az2.T_SDiAn[i] ,&pardtm.daz2.T_SDiAn[i], &pardtm.o2.T_SDiAn[i]  ,&pardtm.do2.T_SDiAn[i], 
                  &pardtm.az.T_SDiAn[i]  ,&pardtm.daz.T_SDiAn[i], &pardtm.t0.T_SDiAn[i]  ,&pardtm.dt0.T_SDiAn[i], 
                  &pardtm.tp.T_SDiAn[i]  ,&pardtm.dtp.T_SDiAn[i] );
	}
// ...... termes in 
    for (i = 1; i <=   dtmindex.Nb_TDi; i++ )
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
		 		  i,  &pardtm.tt.T_TDi[i]  ,&pardtm.dtt.T_TDi[i], &pardtm.h.T_TDi[i]   ,&pardtm.dh.T_TDi[i], 
                  &pardtm.he.T_TDi[i]  ,&pardtm.dhe.T_TDi[i], &pardtm.ox.T_TDi[i]  ,&pardtm.dox.T_TDi[i], 
                  &pardtm.az2.T_TDi[i] ,&pardtm.daz2.T_TDi[i], &pardtm.o2.T_TDi[i]  ,&pardtm.do2.T_TDi[i], 
                  &pardtm.az.T_TDi[i]  ,&pardtm.daz.T_TDi[i], &pardtm.t0.T_TDi[i]  ,&pardtm.dt0.T_TDi[i], 
                  &pardtm.tp.T_TDi[i]  ,&pardtm.dtp.T_TDi[i] );
   }

// ...... termes in 
    for (i = 1; i <=   dtmindex.Nb_AMg; i++ )
	{
     fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
		   		  i,  &pardtm.tt.T_AMg[i]  ,&pardtm.dtt.T_AMg[i], &pardtm.h.T_AMg[i]   ,&pardtm.dh.T_AMg[i], 
                  &pardtm.he.T_AMg[i]  ,&pardtm.dhe.T_AMg[i], &pardtm.ox.T_AMg[i]  ,&pardtm.dox.T_AMg[i], 
                  &pardtm.az2.T_AMg[i] ,&pardtm.daz2.T_AMg[i], &pardtm.o2.T_AMg[i]  ,&pardtm.do2.T_AMg[i], 
                  &pardtm.az.T_AMg[i]  ,&pardtm.daz.T_AMg[i], &pardtm.t0.T_AMg[i]  ,&pardtm.dt0.T_AMg[i], 
                  &pardtm.tp.T_AMg[i]  ,&pardtm.dtp.T_AMg[i] );
   }

// ...... termes in 
    for (i = 1; i <=   dtmindex.Nb_Lon; i++ )   
	{
    fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
				  i,  &pardtm.tt.T_Lon[i]  ,&pardtm.dtt.T_Lon[i], &pardtm.h.T_Lon[i]   ,&pardtm.dh.T_Lon[i], 
                  &pardtm.he.T_Lon[i]  ,&pardtm.dhe.T_Lon[i], &pardtm.ox.T_Lon[i]  ,&pardtm.dox.T_Lon[i], 
                  &pardtm.az2.T_Lon[i] ,&pardtm.daz2.T_Lon[i], &pardtm.o2.T_Lon[i]  ,&pardtm.do2.T_Lon[i], 
                  &pardtm.az.T_Lon[i]  ,&pardtm.daz.T_Lon[i], &pardtm.t0.T_Lon[i]  ,&pardtm.dt0.T_Lon[i], 
                  &pardtm.tp.T_Lon[i]  ,&pardtm.dtp.T_Lon[i]);
   }
// ...... termes in 
	// cdav phas
    for (i = 1; i <=   dtmindex.Nb_dPhas; i++ )
	{
		 fprintf(outfile,"i4 %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e %13.6e %9.2e \n", 
			      i,  &pardtm.tt.T_dPhas[i]  ,&pardtm.dtt.T_dPhas[i], &pardtm.h.T_dPhas[i]   ,&pardtm.dh.T_dPhas[i], 
                  &pardtm.he.T_dPhas[i]  ,&pardtm.dhe.T_dPhas[i], &pardtm.ox.T_dPhas[i]  ,&pardtm.dox.T_dPhas[i], 
                  &pardtm.az2.T_dPhas[i] ,&pardtm.daz2.T_dPhas[i], &pardtm.o2.T_dPhas[i]  ,&pardtm.do2.T_dPhas[i], 
                  &pardtm.az.T_dPhas[i]  ,&pardtm.daz.T_dPhas[i], &pardtm.t0.T_dPhas[i]  ,&pardtm.dt0.T_dPhas[i], 
                  &pardtm.tp.T_dPhas[i]  ,&pardtm.dtp.T_dPhas[i]);
   }

 }

fclose(infile);
if (outfile != NULL)
    fclose(outfile);

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * 
// -- First Verif /  model  >>>> ok
//       Do i = 1,Nb_lat
//      write( * , * ) 'ox(',i,') : ',ox.T_Lat[i]
//      write( * , * ) '   dox(',i,') : ',&pardtm.dox.T_Lat[i]
//       EndDo
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * 

fifteen:   

    if (Iok == 0) 
      {
//       stop;
       printf( " exit: LecDTM" );
      }

} // function InitDTM



 //---------------------------------------------------------------------------
 //
 // ROUTINE: dtm_wrapper
 //
 //> @author Raul Dominguez
 //>
 //> @brief  compute the required arguments for dtm2012 subroutine, call it
 //>              and return the results.
 //
 // INPUT ARGUMENTS:
 //>                    @param[in] latgd         latitude in degrees
 //>                    @param[in] lon          longitude in degrees
 //>                    @param[in] hellp        altitude in km (must be greater than 120)
 //>                    @param[in] in_date      UT date in MJD2000 or calendar date
 //
 // OUTPUT ARGUMENTS:
 //>                    @param[out] ro           density (g/cm^3) at the given position
 //>                    @param[out] ro_unc       density uncertainty
 //>                    @param[out] tinf         exospheric temperature
 //>                    @param[out] tp120
 //>                    @param[out] tz           temperature at the given height
 //>                    @param[out] xmm          mean molecular mass
 //>                    @param[out] d[1]         concentration in atomic hydrogen
 //>                    @param[out] d[2]         concentration in helium
 //>                    @param[out] d[3]         concentration in atomic oxygen
 //>                    @param[out] d[4]         concentration in molecular nitrogen
 //>                    @param[out] d(5)         concentration in molecular oxygen
 //>                    @param[out] d(6)         concentration in atomic nitrogen
 //
 // REVISION HISTORY:
 //
 // version 1.0
 // date 31/07/2012
 // Initial version
 //
 // version 1.1
 // date 10/08/2012
 // Added density uncertainty computation
 //
 // version 1.2
 // date 10/08/2012
 // Changed internal variable dayofyear from int to real to match its kind
 // in DTM2012 subroutine
 // Changed date input, to allow the user to use either MJD2000 or calendar date
 //
 // version 1.3
 // date 11/09/2012
 // Bugfix. The density uncertainty was being called with local solar time in
 // radians, and should be hours
 //
 // version 1.4
 // date 14/09/2012
 // Change. Input parameters are now real (before they were double)
 //
 // version 1.6
 // date 19/09/2012
 // Change in the solar proxy file format (email from Sean Bruinsma at 19/09/2012)
 // Fixed a bug: The am values where not being read properly
 //
 // @version 1.7
 // @date 28/09/2012
 // Bugfix. The interpolated akp value was not being computed properly. In order to
 // interpolate, the minutes and seconds of the user input hour were not being
 // considered
 //---------------------------------------------------------------------------

void dtm_wrapper
    (
      dtm_daterectype& in_date, double lon, int number_of_lines_in_a_file, int number_of_lines_in_f_file, 
	  a_structtype a_indexes[3000], f_structtype f_indexes[3000],
      double f[3], double fbar[3], double akp[5], double& dayofyear, double& hl
    )
{
      //User-entered date is stored in these vars
      int usr_day, usr_month, usr_year, usr_hour, usr_min;
      double usr_sec;
      double usr_hour_decimal;

      //Auxiliaries for akp computation
      // cdav increment by 1 to have the same indices the same between languages
      int a_row_current[9], a_row_former[9], a_row_formerformer[9];
      int a_row_aux[11];
      int a_row_aux_idx[11];
      int a_before, a_after;
      int day_index;

	  int idx, idx2;
	  int const max_lines = 3000;  // 3000 with smaller file 15818 19784
	  // cdav add counter i
	  long int i;
	  //save first_run,a_indexes,f_indexes, number_of_lines_in_a_file, number_of_lines_in_f_file;

	  //======================================================================
      //Process the user input date
      process_input_date (in_date);
      usr_day=in_date.day;
      usr_month=in_date.month;
      usr_year=in_date.year;
      usr_hour=in_date.hour;
      usr_min=in_date.minute;
      usr_sec=in_date.second;

      //Get the solar local time and the day of year
      hl = local_solar_time(lon,usr_hour,usr_min,usr_sec);

	  dayofyear = day_of_year(usr_day,usr_month,usr_year) + (usr_hour/24.0) +                                  
                             (usr_min/(24.0*60.0)) + (usr_sec/(24.0*3600.0));

      // Accrding to dtm2012 documentation: f[2]=0 fbar[2]=0
      // f[1] y fbar[1] are read from f_indexes structure
 //
 // cdav this is somewhat inefficient to find the solar flux and geomagnetic values
 // better to use a technique to find the recnum directly
 //          jd          = jd + mfme/1440.0;
 //          jdspwstarto = floor( jd - jdspwstart);
 //          recnum      = int(jdspwstarto);
 //

      f[2] = -1000.0;
      for (idx=1; idx < number_of_lines_in_f_file; idx++)  // < or <=?? cdav
		{
            if (f_indexes[idx].year == usr_year) 
		      {
                if (f_indexes[idx].month == usr_month) 
			      {
                    if (f_indexes[idx].day == usr_day) 
				      {
                        // f[1] must be the f index corresponding to a day before the user input date. Therefore,
                        // if the first line of the "f" file corresponds to the user input date, there is an error
						  
                        if (idx == 1) 
                            fatal_error(1);
                          else if (idx == number_of_lines_in_f_file) 
                            fatal_error(1);
						
						f[2] = 0.0; 
                        fbar[2] = 0.0;

                        //get f[1] by linear interpolation between f(day-1) and f(day)
                        //get fbar[1] by linear interpolation between f(day) and f(day+1)
						// cdav should be 2086, 118.7 98.0 fbar
                        f[1] = linear_interpolation(0.0, f_indexes[idx-1].f, 24.0, f_indexes[idx].f, hms2hr(usr_hour, usr_min, usr_sec));

                        //if the current line is the last of the file, no interpolation is posible. If this happens, do not
                        //interpolate and issue a warning
                        if (idx != number_of_lines_in_f_file) 
                            fbar[1] = linear_interpolation(0.0, f_indexes[idx].fbar, 24.0, f_indexes[idx+1].fbar, hms2hr(usr_hour, usr_min, usr_sec));
                          else
					      {
                             warning(2);
                             fbar[1] = f_indexes[idx].fbar;
					      }
                 //   exit;
				   }  // if
			   } // if
		   } // if
	    }   //  for

      // Check that the loop above has actually read something. If not, the user input date is not in the data file
      if (f[2] == -1000.0) 
           fatal_error(1);

	  //Find AKP from "a" structure
      //
      //According to the comments in DTM2012:
      // akp[2] = akp[4] = 0
      // akp[1] = kp delayed by 3 hours
      // akp[3] = mean of last 24 hours

      //Also take the following into account
      //    - Kp only takes discrete values: 0, 1/3, 2/3, 1, 4/3....
      //    - Averages must be computed from "a", not from Kp
      //    - For the same reason, interpolations are performed on "a"

      akp[2] = -1000.0;
      for (idx=1; idx <= number_of_lines_in_a_file; idx++ )
	  {
         if (a_indexes[idx].year == usr_year) 
		 {
             if (a_indexes[idx].month == usr_month) 
			 {
                 if (a_indexes[idx].day == usr_day) 
				 {
                    usr_hour_decimal = hms2hr(usr_hour,usr_min,usr_sec);

                    //Each row contains 8 values for a day: from 0h to 3h, from 3h to 6h, and so..
                    //So once the day matches, find the "a" corresponding to the input hour

                    if (usr_hour_decimal <= 3.0) 
                        day_index=1;
                    else if (usr_hour_decimal <= 6.0) 
                        day_index=2;
                    else if (usr_hour_decimal <= 9.0) 
                        day_index=3;
                    else if (usr_hour_decimal <= 12.0) 
                        day_index=4;
                    else if (usr_hour_decimal <= 15.0) 
                        day_index=5;
                    else if (usr_hour_decimal <= 18.0) 
                        day_index=6;
                    else if (usr_hour_decimal <= 21.0) 
                        day_index=7;
                    else if (usr_hour_decimal <= 24.0) 
                        day_index=8;
                    else
                        day_index=-1; //Prevent a warning.
					
                    // Get the row corresponding to the current day and the two days before

                    // If the user input date matches the first or second lines, it is not possible
                    // to compute akp[3]
                    if (idx == 1) 
					    fatal_error(9);
                    else if (idx == 2) 
                        fatal_error(9);
					else
					{
                        for (i = 1; i < 9; i++ )  // cdav set each of the geomagnetic values
						{
					    	a_row_formerformer[i] = a_indexes[idx-2].am[i];
                            a_row_former[i] = a_indexes[idx-1].am[i];
                            a_row_current[i] = a_indexes[idx].am[i];
						}
					}

                    // Write akp values
                    akp[2]=0.0;
                    akp[4]=0.0;

                    //for akp[1], linear interpolation between the nearest "a" values, which are
                    //akp_before and akp_after

                    if (day_index-1 == 0) 
					{
                      a_before = (a_row_former[8]);
                      a_after = (a_row_current[1]);
					}
                    else
					{
                      a_before=(a_row_current[day_index-1]);
                      a_after=(a_row_current[day_index]);
					} 

                    //This line interpolates a between akp_before and akp_after, and then finds akp[1] from it
                    //Note that the time is delayed 3 hours

                    akp[1] = a2K(linear_interpolation(0.0, a_before, 3.0, a_after, usr_hour_decimal - 3*(day_index-1) ));

                    //akp[3] is the average of the last 24 hours. Usually, I will need values from both
                    // a_row_current and a_row_former and even a_row_formerformer

                    //Load all the required am values required for akp[3]
                    //into an auxiliary array. The times (3,6,9...) matching
                    //those values are stores in another auxiliary array

                    //Then compute the mean am value using those arrays

                    //To compute mean am, we assume that am is a piecewise function,
                    //each of whose pieces is a straight line

                    //the auxiliary arrays are filled backwards
                    for (idx2=1; idx2 <= 10; idx2++)
					{

                        if ((day_index+1-idx2) >= 1)  //get the value from the current line
			    		{
                           a_row_aux[11-idx2] = a_row_current[day_index+1-idx2];
                           a_row_aux_idx[11-idx2] = 3*(day_index+1-idx2);
			    		}
                        else if ((day_index+1-idx2) >= -7)  //get the value from the previous line
			    		{
                           a_row_aux[11-idx2] = a_row_former[(day_index+1-idx2)+8];
                           a_row_aux_idx[11-idx2] = 3*(day_index+1-idx2);
			    		}
                        else if ((day_index+1-idx2) >= -8)  //get the value from the previous line
				    	{
                           a_row_aux[11-idx2] = a_row_formerformer[(day_index+1-idx2)+16];
                           a_row_aux_idx[11-idx2] = 3*(day_index+1-idx2);
			    		}

					}  // for

                    akp[3] = 0.0;

                    //Integrate from T-24 to the next known point, then between known
                    //points and finally from the last known point before T up to T

                    //First integral
                    akp[3] = akp[3] + (a_row_aux_idx[2]-(usr_hour_decimal-24.0))*0.5* 
                                    (a_row_aux[2]+linear_interpolation(  0.0,            
                                                                     a_row_aux[1], 
                                                                         3.0,            
                                                                     a_row_aux[2], 
                                      (usr_hour_decimal-24.0) -  a_row_aux_idx[1]  
                                    ));

                    //Seven integrals
                    for (idx2 = 1; idx2 <= 7; idx2++)
					{
                     akp[3] = akp[3]+((3.0/2.0)*(a_row_aux[idx2+1] + a_row_aux[idx2+2]));
					}

                    //Last integral
                    akp[3] = akp[3] + (((usr_hour_decimal-a_row_aux_idx[9])*0.5 * 
                             (a_row_aux[9] + 
        				     linear_interpolation (0.0, a_row_aux[9], 3.0, a_row_aux[10], usr_hour_decimal - a_row_aux_idx[9]))));


                    //The akp[3] value is the sum found previously divided by 24, and
                    // passed to the a2K function
                    akp[3] = a2K(akp[3]/24.0);

                  //  exit;

				 }
			 }
		 }
      
      } // for

      //Check that the loop above has actually read something. If not, the user input date is not in the data file
      if (akp[2] == -1000.0) 
         fatal_error(2);

}  // function dtm_wrapper

