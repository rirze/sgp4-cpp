/*        ----------------------------------------------------------------
 * 
 *                               DTM_12.cpp
 * 
 *   this file contains common routines for the DTM-2012 atmospheric model.
 *   note that the indices are increased by one so they will appear the same as
 *   original fortran-90 source.
 * 
 *     current :
 *                6 aug 13  david vallado
 *                            conversion to c ++ 
 *     changes :
 *               10 may 13  sean bruinsma
 *                            original baseline
/*  ---------------------------------------------------------------------- */

#include "StdAfx.h"

#include "DTM_12.h"

/*  -------------------------- local rountines --------------------------- */


 //---------------------------------------------------------------------------
 //
 // ROUTINE: dtm2012
 //
 //> @author Sean Bruinsma
 //>
 //> @brief  calculation of temperature and density with DTM2012
 //
 // PROTOTYPE:
 //                     dtm2012 (
 //                              double intent(in)   day
 //                              double intent(in)   f[2]
 //                              double intent(in)   fbar[2]
 //                              double intent(in)   akp[4]
 //                              double intent(in)   hellp
 //                              double intent(in)   hl
 //                              double intent(in)   alat
 //                              double intent(in)   lon
 //                              double intent(out)   tz
 //                              double intent(out)   tinf
 //                              double intent(out)   tp120
 //                              double intent(out)   ro
 //                              double intent(out)   d[6]
 //                              double intent(out)   wmm
 //                             )
 //
 //
 // INPUT ARGUMENTS:
 //>                    @param[in] day day-of-year [1-366]
 //>                    @param[in] f[2] f[1] = instantaneous flux at (day - 1) / f[2] = 0
 //>                    @param[in] fbar[2] fbar[1] = mean flux at t / fbar[2] = 0.
 //>                    @param[in] akp[4] kp delayed by 3 hours, akp[3] = mean of last 24 hours / akp[2] & akp[4] = 0
 //>                    @param[in] hellp altitude (in km) greater than 120 km
 //>                    @param[in] hl local time (in radian)
 //>                    @param[in] alat latitude (in radian)
 //>                    @param[in] lon longitude (in radian)
 //
 //
 // OUTPUT ARGUMENTS:
 //>                    @param[out] ro           density (g/cm^3) at the given position
 //>                    @param[out] tinf         exosphere temperature
 //>                    @param[out] tz           temperature at the given height
 //>                    @param[out] wmm          mean molecular mass
 //>                    @param[out] tp120	temperature gradient at 120 km
 //>                    @param[out] d[6]         partial density atomic hydrogen [1]
 //>                                             partial density helium [2]
 //>                                             partial density atomic oxygen [3]
 //>                                             partial density molecular nitrogen [4]
 //>                                             partial density molecular oxygen [5]
 //>                                             partial density atomic nitrogen [6] (unused)
 //
 //> @date 06/2012
 //
 //---------------------------------------------------------------------------
 // * aut SB         Mod PS     
 // * ver 06/10/2009   06/2012
 //
 // * rol calculation of temperature and density with DTM2012  
 // * par * *  INPUT * * 
 //     day      = day-of-year [1-366]
 //     f        = f[1] = instantaneous flux at (day - 1) / f[2] = 0.
 //     fbar     = fbar[1] = average flux at t  / fbar[2] = 0.
 //     akp      = akp[1] =  kp delayed by 3 hours, akp[3] = mean of last 24 hours / akp[2] & akp[4] = 0.
 //     hellp     = altitude (in km) greater than 120 km
 //     hl       = local time (in radian)
 //     alat     = latitude (in radian)
 //     lon     = longitude (in radian)
 // * par * *  OUTPUT * * 
 //     tz        = temperature at altitude -> hellp
 //     tinf      = exosphere temperature
 //     d[1]      = partial density atomic hydrogen
 //     d[2]      = partial density helium
 //     d[3]      = partial density atomic oxygen
 //     d[4]      = partial density molecular nitrogen
 //     d[5]      = partial density molecular oxygen
 //     d[6]      = partial density atomic nitrogen
 //     ro        = density (total) in g/cm3
 //     wmm       = mean molecular mass in g
 // cdav increment indicies by one for compatibility to fortran code 
/*  ---------------------------------------------------------------------- */

void dtm2012
    (
	  plgdtmtype& plgdtm, hlocaltype& hlocal, eclipttype& eclipt, datmotype& datmo, constype& cons, pardtmtype& pardtm,
	  double day, double f[3], double fbar[3], double akp[5], double hellp, double hl, double alat, double lon,
      double& tz, double& tinf, double& tp120, double& ro, double d[7], double& wmm
	)
    {
     //.. Local Scalars .. 
	 char longstr1[150];
     int i, i1, ialt;
     int ityp = 0;
     int i2, n;
     double akp2,asc,attenuat,c,c2,c4,cecl4,cl,cmg,cp,cts,delkm,dt120,dtinf, 
            dtp120,gamma,gdelaz,gdelh,gdelo,gdelt0,gdeltp,s2,sasc,tinftz,ts,zeta;
     double cpmg = 0.19081, re = 6356.77, rgas = 831.4;
 
     double akp4,casc,cecl2,clmlmg,cmg2,cmg4,cpcl,cpsl,ctl,ctsg,difkm,dzeta, 
            dzeta2,expsz,gdelaz2,gdelhe,gdelo2,gdelt,glb,s,secl2,sigma,sigzeta, 
            sl,sp,stl,sts,stsg,t,t120sd,t120tt,t120tz,tp120sd,tsg,unsure,upapg;

     double xlmg = -1.2392;
     double t120 = 0.0, xlog = 0.0;
     double cose = 0.9175, gsurf = 980.665, sine = 0.3978, spmg = 0.98163, zero = 0.0;
     double zlb;
     double zlb0 = 120.0;
   
     //.. Local Arrays 
     double cc[7] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0}; 
     double dbase[7] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
     double fz[7] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};

     //.. Data Declarations .. 
	 // cdav increment all arrays so they can begin at 1
     static double alefa[7] = {0.0, -0.40, -0.38, 0.0, 0.0, 0.0, 0.0};
     static int    ma[7]    = {0, 1, 4, 16, 28, 32, 14};
     static double vma[7]   = {0.0, 1.6606e-24, 6.6423e-24, 26.569e-24, 46.4958e-24, 53.1381e-24, 23.2479e-24};

     // ... Executable Statements ...
     zlb = zlb0;

     ialt = int(hellp);
     ro = 0.0;

     dtinf = 0.0;
     dt120 = 0.0;
     dtp120 = 0.0;
     fz[1] = 0.0;
     fz[2] = 0.0;
     fz[3] = 0.0;
     fz[4] = 0.0;
     fz[5] = 0.0;
     fz[6] = 0.0;
     //
	 pardtm.dtt.T_one  = 0.0;
     pardtm.dh.T_one   = 0.0;
     pardtm.dhe.T_one  = 0.0;
     pardtm.dox.T_one  = 0.0;
     pardtm.daz2.T_one = 0.0;
     pardtm.do2.T_one  = 0.0;
     pardtm.daz.T_one  = 0.0;
     pardtm.dt0.T_one  = 0.0;
     pardtm.dtp.T_one  = 0.0;
  
     //   calcul des polynomes de legendre
     c   = sin(alat);
     c2  = c * c;
     c4  = c2 * c2;
     s   = cos(alat);
     s2  = s * s;
     plgdtm.p10 = c;
     plgdtm.p20 = 1.5 * c2 - 0.5;
     plgdtm.p30 = c * (2.5 * c2 - 1.5);
     plgdtm.p40 = 4.375 * c4 - 3.75 * c2 + 0.375;
     plgdtm.p50 = c * (7.875 * c4 - 8.75 * c2 + 1.875);
     plgdtm.p60 = (5.5 * c * plgdtm.p50 - 2.5 * plgdtm.p40) / 3.0;
     plgdtm.p11 = s;
     plgdtm.p21 = 3.0 * c * s;
     plgdtm.p31 = s * (7.5 * c2 - 1.5);
     plgdtm.p41 = c * s * (17.5 * c2 - 7.5);
     plgdtm.p51 = s * (39.375 * c4 - 26.25 * c2 + 1.875);
     plgdtm.p22 = 3.0 * s2;
     plgdtm.p32 = 15.0 * c * s2;
     plgdtm.p42 = s2 * (52.5 * c2 - 7.5);
     plgdtm.p52 = 3.0 * c * plgdtm.p42 - 2.0 * plgdtm.p32;
     plgdtm.p62 = 2.75 * c * plgdtm.p52 - 1.75 * plgdtm.p42;
     plgdtm.p33 = 15.0 * s * s2;

     //   calcul des polynomes de legendre / pole magnetique (79n,71w)
     clmlmg = cos(lon - xlmg);
     sp     = s * cpmg * clmlmg + c * spmg;
     
     cmg    = sp; // pole magnetique
     cmg2   = cmg * cmg;
     cmg4   = cmg2 * cmg2;
     plgdtm.p10mg  = cmg;
     plgdtm.p20mg  = 1.5 * cmg2 - 0.5;
     plgdtm.p40mg  = 4.375 * cmg4 - 3.75 * cmg2 + 0.375;
     
     //   heure locale 
     hlocal.hl0 = hl;
     hlocal.ch  = cos(hlocal.hl0);
     hlocal.sh  = sin(hlocal.hl0);
     hlocal.c2h = hlocal.ch * hlocal.ch - hlocal.sh * hlocal.sh;
     hlocal.s2h = 2.0 * hlocal.ch * hlocal.sh;
     hlocal.c3h = hlocal.c2h * hlocal.ch - hlocal.s2h * hlocal.sh;
     hlocal.s3h = hlocal.s2h * hlocal.ch + hlocal.c2h * hlocal.sh;
     
     //   calcul of fonction g(l) / tinf, t120, tp120
     //// new version declaration of tt,dtt en struct dtm
     gldtm_XX(plgdtm, hlocal, datmo, f, fbar, akp, day, pardtm.tt, pardtm.dtt, gdelt, 1.0, lon);
     pardtm.dtt.T_one = 1.0 + gdelt;
     tinf = pardtm.tt.T_one * pardtm.dtt.T_one;

     gldtm_XX(plgdtm, hlocal, datmo, f, fbar, akp, day, pardtm.t0, pardtm.dt0, gdelt0, 1.0, lon);
     pardtm.dt0.T_one = 1.0 + gdelt0;
     t120 = pardtm.t0.T_one * pardtm.dt0.T_one;

     gldtm_XX(plgdtm, hlocal, datmo, f, fbar, akp, day, pardtm.tp, pardtm.dtp, gdeltp, 1.0, lon);
     pardtm.dtp.T_one = 1.0 + gdeltp;
     tp120 = pardtm.tp.T_one * pardtm.dtp.T_one;

     //-----------------------------------------------------------------------------
     //   calcul of concentrations n(z): H, HE, O, N2, O2, N
     sigma = tp120 / (tinf - t120);
     dzeta = (re + zlb) / (re + hellp);
     zeta  = (hellp - zlb) * dzeta;
     dzeta2 = dzeta * dzeta;
     sigzeta =  sigma * zeta;
     expsz  = exp(-sigzeta);
     tz    = tinf - (tinf - t120) * expsz;

     gldtm_XX(plgdtm, hlocal, datmo, f, fbar, akp, day, pardtm.h, pardtm.dh, gdelh, 0.0, lon);
     pardtm.dh.T_one = exp(gdelh);
     dbase[1] = pardtm.h.T_one * pardtm.dh.T_one;

     gldtm_XX(plgdtm, hlocal, datmo, f, fbar, akp, day, pardtm.he, pardtm.dhe, gdelhe, 0.0, lon);
     pardtm.dhe.T_one = exp(gdelhe);
     dbase[2] =  pardtm.he.T_one * pardtm.dhe.T_one;

     gldtm_XX(plgdtm, hlocal, datmo, f, fbar, akp, day, pardtm.ox, pardtm.dox, gdelo, 1.0, lon);
     pardtm.dox.T_one = exp(gdelo);
     dbase[3] = pardtm.ox.T_one * pardtm.dox.T_one;
 
     gldtm_XX(plgdtm, hlocal, datmo, f, fbar, akp, day, pardtm.az2, pardtm.daz2, gdelaz2, 1.0, lon);
     pardtm.daz2.T_one = exp(gdelaz2);
     dbase[4] = pardtm.az2.T_one * pardtm.daz2.T_one;

     gldtm_XX(plgdtm, hlocal, datmo, f, fbar, akp, day, pardtm.o2, pardtm.do2, gdelo2, 1.0, lon);
     pardtm.do2.T_one = exp(gdelo2);
     dbase[5] =  pardtm.o2.T_one * pardtm.do2.T_one;

     gldtm_XX(plgdtm, hlocal, datmo, f, fbar, akp, day, pardtm.az, pardtm.daz, gdelaz, 1.0, lon);
     pardtm.daz.T_one = exp(gdelaz);
     dbase[6] = pardtm.az.T_one * pardtm.daz.T_one;
     //
     glb = gsurf / pow(1.0 + zlb/re, 2);
     glb = glb / (sigma * rgas * tinf);
     t120tz = t120 / tz;
     tinftz = tinf / tz;
     for (i = 1; i <= 6; i++)
	 {
         gamma = ma[i] * glb;
         upapg = 1.0 + alefa[i] + gamma;
         fz[i] = pow( t120tz, upapg ) * exp(-sigzeta * gamma);
         //   concentrations en H, HE, O, N2, O2, N
         cc[i] = dbase[i] * fz[i];
         //   densites en H, HE, O, N2, O2, N
         d[i] = cc[i] * vma[i];
         //   densite totale
         ro = ro + d[i];
	 }

     //  average of atomic mass                              
     wmm = ro/(vma[1] * (cc[1] + cc[2] + cc[3] + cc[4] + cc[5] + cc[6]));
    } // function dtm2012


//---------------------------------------------------------------------------
//
// ROUTINE: densisty_uncertainty
//
//> @author Sean Bruinsma
//>
//> @brief  calculation of density uncertainty
//
// PROTOTYPE:
//        density_uncertainty (
//                              double intent(in)   alt
//                              double intent(in)   latgd
//                              double intent(in)   lst
//                              double intent(in)   flux
//                              double intent(in)   kp
//                              double intent(out)   unc
//                             )
//
//
// INPUT ARGUMENTS:
//>                    @param[in] alt altitude in km (NB: uncertainties NOT correct - too big - for altitudes<300 km)
//>                    @param[in] latgd latitude in degrees
//>                    @param[in] lst local solar time in hours (0. - 23.999)
//>                    @param[in] flux mean solar flux (sfu)
//>                    @param[in] kp geomagnetic activity (0. - 9.0)
//
//
// OUTPUT ARGUMENTS:
//>                    @param[out] unc uncertainty (1-sigma) due to density variations below model resolution, in _ of density
//
//> @date
//
//
// alt  = altitude in km (NB: uncertainties NOT correct - too big - for altitudes<300 km)
// latgd  = latitude in degrees
// lst  = local solar time in hours (0. - 23.999)
// flux = mean solar flux (sfu)
// kp   = geomagnetic activity (0. - 9.0)
// unc  = uncertainty (1-sigma) due to density variations below model resolution, in _ of density
//
//NB: based on relative density variations with scales < 2400 km, at 350 and 500 km altitude only,
//    below and above that altitude uncertainties are extrapolated or constants
//
//  Raul Dominguez: Modification for ATMOP DTM2012 wrapper:
//                  Modified so the input files are read only once
//
//  Raul Dominguez: Modification for ATMOP DTM2012 wrapper:
//                  modified so arguments alt and flux are not changed within the routine
//                  I see no reason for such behaviour
//
//  Raul Dominguez: Modified to allow setting file units in a external module
//                  This improves portability
//---------------------------------------------------------------------------

void density_uncertainty
   ( 
	 double nomgrid[25][19], double alt_scale[25][19], double kp_scale[25][19], 
	 double alt, double latgd, double lst, double flux, double kp, double& unc
   )
   {
     double steplat, unc_nom, unc_alt, unc_kp, unc_f, alti_factor, kp_factor, flux_factor, flux2;
	 double rad2deg;
     int  ind_lat, ind_lst;

     //radg modification
     double  alt_aux, flux_aux;
// cdav move definitions to test

	 rad2deg = 57.2957795131;
     //radg modification
     alt_aux = alt;
     flux_aux = flux;

     //radg modification to allow setting file units and names externally
     unc = -999.0;

// cdav move if firstrun section to main
     steplat = 10.0;
	 // cdav change latgd to deg for the index calculation * rad2deg
     ind_lat = int((latgd * rad2deg + 90.0)/steplat) + 1;
     ind_lst = int(lst) + 1;
     // ---
     unc_nom = nomgrid[ind_lst][ind_lat];     //nominal relative variability: @350 km, flux = 65, kp<3

     if(alt_aux > 650.0) 
 		 alt_aux = 650.0;                     //in fact no information above 500 km
     alti_factor = (alt_aux - 350.0)/150.0;   //altitude effect: larger with increasing altitude
     if(alt_aux < 350.0) 
		 alti_factor = 0.0;                   //no information yet; will be computed with GOCE
     unc_alt = unc_nom * (1.0 + alti_factor * alt_scale[ind_lst][ind_lat]);

     kp_factor = (kp - 4.0)/2.0;              //geomagnetic activity effect
     if(kp < 4.0) 
 		 kp_factor = 0.0;
     unc_kp = unc_alt * (1.0 + kp_factor * kp_scale[ind_lst][ind_lat]);

     if(flux_aux > 200.0) 
	 	 flux_aux = 200.0;
     flux2 = flux_aux * flux_aux;             //81-day mean solar activity effect
     flux_factor = 2.5506 - 3.7403e-2 * flux_aux + 2.4455e-4 * flux2 - (5.5582e-7 * flux_aux * flux2);
     unc_f = flux_factor * unc_kp;

     // --- uncertainty in _
     unc  = unc_f * 100.0;
    } // function density_uncertainty



// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
// SB 06/03/2009 MOD PS 04/2012
// Corrections & new variables
// * rol calculation of function g(l)  for dtm2009 & dtm2012
//
//     DTM =  table of coefficients for g(l) or for each component
//     ddtm = table of derivatives dg(l)/da
//     ff0 = 1 : for oxygen, nitrogen, helium, temperature
//     ff0 = 0 : hydrogen
//
//     gdel = result for g(l)
//     lon = longitude (not used) 
//       double intent(in)   day,ff0,lon;
//       double intent(out)   gdel;
//       double dimension[2], intent(in)   f,fbar;
//       double dimension[4], intent(in)   akp;
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

void gldtm_XX
	(
	  plgdtmtype& plgdtm, hlocaltype& hlocal, datmotype& datmo, 
	  double f[3], double fbar[3], double akp[5], double day, DTM_12type& DTM_12, ddtm_12type& ddtm_12, 
	  double& gdel, double ff0, double lon
    )
	{
     int   kle_eq = 0;
     //.. Local Scalars .. 
     int   i;
     int   ikp = 0;
     int   ikpm;
     double  a74,a77,a78,a88,f1f,fp;
     double  c2fi = 0.0;
     double  a89,a90,a91,aada,clfl,cos2te,coste,dakp,dakpm,dkp,dkpm,f0,fp1, 
             rsin2te,slfl;
     double  rot = 0.017214206,
		     rot2 = 0.034428412,
			 roth = 0.261799387, 
             rots = 7.27220e-05;
     double  rsinte;
     // 
     //.. Local Arrays .. 
	 // cdav increment array size by 1 so indicies match fortran
     double fbm150[3],fmfb[3];

	 fbm150[1] = 0.0;
	 fbm150[2] = 0.0;
	 fmfb[1] = 0.0;
	 fmfb[2] = 0.0;

     // ... Executable Statements ...
     //   termes in latitude
     ddtm_12.T_lat[1] = plgdtm.p20;
     ddtm_12.T_lat[2] = plgdtm.p40;
     ddtm_12.T_lat[3] = plgdtm.p10;
     ddtm_12.T_lat[4] = plgdtm.p30;
     ddtm_12.T_lat[5] = plgdtm.p50;
     ddtm_12.T_lat[6] = plgdtm.p60;

     //   termes of flux
     fmfb[1] = f[1] - fbar[1];
     fmfb[2] = f[2] - fbar[2];
     fbm150[1] = fbar[1] - 150.0;
     fbm150[2] = fbar[2];

     ddtm_12.T_flux[1] = fmfb[1];
     ddtm_12.T_flux[3] = fbm150[1];
       
     ddtm_12.T_flux[1] = ddtm_12.T_flux[1] + DTM_12.T_flux[5] * fmfb[2];
     ddtm_12.T_flux[3] = ddtm_12.T_flux[3] + DTM_12.T_flux[6] * fbm150[2];
    
     ddtm_12.T_flux[5] = fmfb[2] * (DTM_12.T_flux[1] + 2.0 * DTM_12.T_flux[2] * ddtm_12.T_flux[1] 
                         + DTM_12.T_flux[7] * plgdtm.p10 + DTM_12.T_flux[8] * plgdtm.p20 + DTM_12.T_flux[9] * plgdtm.p30);

     ddtm_12.T_flux[6] = fbm150[2] * (DTM_12.T_flux[3] + 2.0 * DTM_12.T_flux[4] * ddtm_12.T_flux[3] 
                         + DTM_12.T_flux[10] * plgdtm.p10 + DTM_12.T_flux[11] * plgdtm.p20 + DTM_12.T_flux[12] * plgdtm.p30);

     ddtm_12.T_flux[2]  = ddtm_12.T_flux[1] * ddtm_12.T_flux[1];
     ddtm_12.T_flux[4]  = ddtm_12.T_flux[3] * ddtm_12.T_flux[3];
     ddtm_12.T_flux[7]  = ddtm_12.T_flux[1] * plgdtm.p10;
     ddtm_12.T_flux[8]  = ddtm_12.T_flux[1] * plgdtm.p20;
     ddtm_12.T_flux[9]  = ddtm_12.T_flux[1] * plgdtm.p30;
     ddtm_12.T_flux[10] = ddtm_12.T_flux[3] * plgdtm.p20;
     ddtm_12.T_flux[11] = ddtm_12.T_flux[3] * plgdtm.p30;
     ddtm_12.T_flux[12] = ddtm_12.T_flux[3] * plgdtm.p40;

     //   termes in kp
     c2fi = 1.0 - plgdtm.p10mg * plgdtm.p10mg;

     dkp = akp[1] + (DTM_12.T_kp[5] + c2fi * DTM_12.T_kp[6]) * akp[2];
     dakp = DTM_12.T_kp[1] + DTM_12.T_kp[2] * plgdtm.p20mg + DTM_12.T_kp[11] * plgdtm.p40mg + 
            2.0 * dkp * (DTM_12.T_kp[3] + DTM_12.T_kp[4] * plgdtm.p20mg + DTM_12.T_kp[14] * 2.0 * dkp * dkp);

     ddtm_12.T_kp[5] = dakp * akp[2];
     ddtm_12.T_kp[6] =  ddtm_12.T_kp[5] * c2fi;

     dkpm = akp[3] + DTM_12.T_kp[10] * akp[4];

     dakpm = DTM_12.T_kp[7] + DTM_12.T_kp[8] * plgdtm.p20mg + DTM_12.T_kp[12] * plgdtm.p40mg + 
             2.0 * dkpm * (DTM_12.T_kp[9] + DTM_12.T_kp[13] * plgdtm.p20mg + 
             DTM_12.T_kp[15] * 2.0 * dkpm * dkpm);

     ddtm_12.T_kp[10] = dakpm * akp[4];

     ddtm_12.T_kp[1]  = dkp;
     ddtm_12.T_kp[2]  = plgdtm.p20mg * dkp;
     ddtm_12.T_kp[11] = plgdtm.p40mg * dkp;
     ddtm_12.T_kp[3]  = dkp * dkp;
     ddtm_12.T_kp[4]  = plgdtm.p20mg * ddtm_12.T_kp[3];
     ddtm_12.T_kp[14] = ddtm_12.T_kp[3] * ddtm_12.T_kp[3];
     ddtm_12.T_kp[7]  = dkpm;
     ddtm_12.T_kp[8]  = plgdtm.p20mg * dkpm;
     ddtm_12.T_kp[12] = plgdtm.p40mg * dkpm;
     ddtm_12.T_kp[9]  = dkpm * dkpm;
     ddtm_12.T_kp[13] = plgdtm.p20mg * ddtm_12.T_kp[9];
     ddtm_12.T_kp[15] = ddtm_12.T_kp[9] * ddtm_12.T_kp[9];

     //   function: g(l) non periodic
     f0 = DTM_12.T_flux[1] * ddtm_12.T_flux[1] + DTM_12.T_flux[2] * ddtm_12.T_flux[2]  
         + DTM_12.T_flux[3] * ddtm_12.T_flux[3] + DTM_12.T_flux[4] * ddtm_12.T_flux[4] 
         + DTM_12.T_flux[7] * ddtm_12.T_flux[7] + DTM_12.T_flux[8] * ddtm_12.T_flux[8]  
         + DTM_12.T_flux[9] * ddtm_12.T_flux[9]  + DTM_12.T_flux[10] * ddtm_12.T_flux[10]  
         + DTM_12.T_flux[11] * ddtm_12.T_flux[11] + DTM_12.T_flux[12] * ddtm_12.T_flux[12];

     f1f = 1.0 + f0 * ff0;
     //     write(6, * ) ' ff0,f0,f1f ',ff0,f0,f1f

     f0 = f0 + DTM_12.T_lat[1] * ddtm_12.T_lat[1] + DTM_12.T_lat[2] * ddtm_12.T_lat[2] 
            + DTM_12.T_lat[3] * ddtm_12.T_lat[3] + DTM_12.T_lat[4] * ddtm_12.T_lat[4] 
            + DTM_12.T_kp[1] * ddtm_12.T_kp[1] + DTM_12.T_kp[2] * ddtm_12.T_kp[2] 
            + DTM_12.T_kp[3] * ddtm_12.T_kp[3] + DTM_12.T_kp[4] * ddtm_12.T_kp[4] 
            + DTM_12.T_kp[11] * ddtm_12.T_kp[11] + DTM_12.T_kp[7] * ddtm_12.T_kp[7] 
            + DTM_12.T_kp[8] * ddtm_12.T_kp[8] + DTM_12.T_kp[9] * ddtm_12.T_kp[9] 
            + DTM_12.T_kp[12] * ddtm_12.T_kp[12] + DTM_12.T_kp[13] * ddtm_12.T_kp[13] 
            + DTM_12.T_kp[14] * ddtm_12.T_kp[14] + DTM_12.T_kp[15]  * ddtm_12.T_kp[15]  
            + DTM_12.T_lat[5] * ddtm_12.T_lat[5] + DTM_12.T_lat[6] * ddtm_12.T_lat[6];

     //   terms annual & symetric in latitude 
     ddtm_12.T_SLat[1] = cos(rot * (day - DTM_12.T_dPhas[1]));
     ddtm_12.T_SLat[2] = plgdtm.p20 * ddtm_12.T_SLat[1];

     //   terms semi-annual & symetric in latitude
     ddtm_12.T_SASLat[1] = cos(rot2 * (day - DTM_12.T_dPhas[2]));
     ddtm_12.T_SASLat[2] = plgdtm.p20 * ddtm_12.T_SASLat[1];

     //   terms annual & non-symetric in latitude 
     coste = cos(rot * (day - DTM_12.T_dPhas[3]));
     ddtm_12.T_NSLat[1] = plgdtm.p10 * coste;
     ddtm_12.T_NSLat[2] = plgdtm.p30 * coste;
     ddtm_12.T_NSLat[3] = ddtm_12.T_flux[3] * ddtm_12.T_NSLat[1];
     //      ddtm_12.T_NSLat[3] = p50 * coste

     //   terms semi-annual  non-symetric in latitude 
     cos2te = cos(rot2 * (day - DTM_12.T_dPhas[4]));
     ddtm_12.T_SANSLat[1] = plgdtm.p10 * cos2te;
     ddtm_12.T_SANSLat[2] = plgdtm.p30 * cos2te;
     ddtm_12.T_SANSLat[3] = ddtm_12.T_flux[3] * ddtm_12.T_SANSLat[1];
     //      ddtm_12.T_SANSLat[3] = p50 * cos2te

     //   terms diurnal (& annual coupled)
     ddtm_12.T_DiAn[1]  = plgdtm.p11 * hlocal.ch;
     ddtm_12.T_DiAn[2]  = plgdtm.p31 * hlocal.ch;
     ddtm_12.T_DiAn[3]  = ddtm_12.T_flux[3] * ddtm_12.T_DiAn[1] ;
     ddtm_12.T_DiAn[4]  = ddtm_12.T_DiAn[1] * coste;
     ddtm_12.T_DiAn[5]  = plgdtm.p21 * hlocal.ch * coste; 
     ddtm_12.T_DiAn[6]  = plgdtm.p11 * hlocal.sh;
     ddtm_12.T_DiAn[7]  = plgdtm.p31 * hlocal.sh;
     ddtm_12.T_DiAn[8]  = ddtm_12.T_flux[3] * ddtm_12.T_DiAn[6];
     ddtm_12.T_DiAn[9]  = ddtm_12.T_DiAn[6] * coste;
     ddtm_12.T_DiAn[10] = plgdtm.p21 * hlocal.sh * coste;
     ddtm_12.T_DiAn[11] = plgdtm.p51 * hlocal.ch;
     ddtm_12.T_DiAn[12] = plgdtm.p51 * hlocal.sh;  

     //   terms semi-diurnes (& annual coupled)
     ddtm_12.T_SDiAn[1]  = plgdtm.p22 * hlocal.c2h;
     ddtm_12.T_SDiAn[2]  = plgdtm.p42 * hlocal.c2h;
     ddtm_12.T_SDiAn[3]  = plgdtm.p32 * hlocal.c2h * coste;
     ddtm_12.T_SDiAn[4]  = plgdtm.p22 * hlocal.s2h;
     ddtm_12.T_SDiAn[5]  = plgdtm.p42 * hlocal.s2h;
     ddtm_12.T_SDiAn[6]  = plgdtm.p32 * hlocal.s2h * coste;
     ddtm_12.T_SDiAn[7]  = plgdtm.p32 * hlocal.c2h; //coeff. rajoute pour tp120/t120 (slb)
     ddtm_12.T_SDiAn[8]  = plgdtm.p32 * hlocal.s2h;
     ddtm_12.T_SDiAn[9]  = ddtm_12.T_flux[3] * ddtm_12.T_SDiAn[1];
     ddtm_12.T_SDiAn[10] = ddtm_12.T_flux[3] * ddtm_12.T_SDiAn[4];
     ddtm_12.T_SDiAn[11] = plgdtm.p62 * hlocal.c2h;
     ddtm_12.T_SDiAn[12] = plgdtm.p62 * hlocal.s2h;
  
     //   terms ter-diurnes
     ddtm_12.T_TDi[1] = plgdtm.p33 * hlocal.c3h;
     ddtm_12.T_TDi[2] = plgdtm.p33 * hlocal.s3h;
  
     //   function periodic -> g(l) 
     fp = DTM_12.T_SLat[1]    * ddtm_12.T_SLat[1]   + DTM_12.T_SLat[2]   * ddtm_12.T_SLat[2] 
         + DTM_12.T_SASLat[1] * ddtm_12.T_SASLat[1] + DTM_12.T_SASLat[2] * ddtm_12.T_SASLat[2]
         + DTM_12.T_NSLat[1]  * ddtm_12.T_NSLat[1]  + DTM_12.T_NSLat[2]  * ddtm_12.T_NSLat[2]  
         + DTM_12.T_NSLat[3]  * ddtm_12.T_NSLat[3]  + DTM_12.T_SANSLat[1]* ddtm_12.T_SANSLat[1] 
         + DTM_12.T_DiAn[1]   * ddtm_12.T_DiAn[1]   + DTM_12.T_DiAn[2]   * ddtm_12.T_DiAn[2] 
         + DTM_12.T_DiAn[3]   * ddtm_12.T_DiAn[3]   + DTM_12.T_DiAn[4]   * ddtm_12.T_DiAn[4] 
         + DTM_12.T_DiAn[5]   * ddtm_12.T_DiAn[5]   + DTM_12.T_DiAn[6]   * ddtm_12.T_DiAn[6] 
         + DTM_12.T_DiAn[7]   * ddtm_12.T_DiAn[7]   + DTM_12.T_DiAn[8]   * ddtm_12.T_DiAn[8] 
         + DTM_12.T_DiAn[9]   * ddtm_12.T_DiAn[9]   + DTM_12.T_DiAn[10]  * ddtm_12.T_DiAn[10] 
         + DTM_12.T_SDiAn[1]  * ddtm_12.T_SDiAn[1]  + DTM_12.T_SDiAn[3]  * ddtm_12.T_SDiAn[3] 
         + DTM_12.T_SDiAn[4]  * ddtm_12.T_SDiAn[4]  + DTM_12.T_SDiAn[6]  * ddtm_12.T_SDiAn[6] 
         + DTM_12.T_TDi[1]    * ddtm_12.T_TDi[1]    + DTM_12.T_TDi[2]    * ddtm_12.T_TDi[2] 
         + DTM_12.T_SDiAn[2]  * ddtm_12.T_SDiAn[2]  + DTM_12.T_SDiAn[5]  * ddtm_12.T_SDiAn[5] 
         + DTM_12.T_SANSLat[2]* ddtm_12.T_SANSLat[2]+ DTM_12.T_SANSLat[3]* ddtm_12.T_SANSLat[3] 
         + DTM_12.T_SDiAn[7]  * ddtm_12.T_SDiAn[7]  + DTM_12.T_SDiAn[8]  * ddtm_12.T_SDiAn[8]  
         + DTM_12.T_SDiAn[9]  * ddtm_12.T_SDiAn[9]  + DTM_12.T_SDiAn[10] * ddtm_12.T_SDiAn[10] 
         + DTM_12.T_SDiAn[11] * ddtm_12.T_SDiAn[11] + DTM_12.T_SDiAn[12] * ddtm_12.T_SDiAn[12]  
         + DTM_12.T_DiAn[11]  * ddtm_12.T_DiAn[11]  + DTM_12.T_DiAn[12]  * ddtm_12.T_DiAn[12]; 
  
     //   terms magnetic activity 
     ddtm_12.T_AMg[1] = plgdtm.p10 * coste * dkp;
     ddtm_12.T_AMg[2] = plgdtm.p30 * coste * dkp;
     ddtm_12.T_AMg[3] = plgdtm.p50 * coste * dkp;
     ddtm_12.T_AMg[4] = plgdtm.p11 * hlocal.ch * dkp;
     ddtm_12.T_AMg[5] = plgdtm.p31 * hlocal.ch * dkp;
     ddtm_12.T_AMg[6] = plgdtm.p51 * hlocal.ch * dkp;
     ddtm_12.T_AMg[7] = plgdtm.p11 * hlocal.sh * dkp;
     ddtm_12.T_AMg[8] = plgdtm.p31 * hlocal.sh * dkp;
     ddtm_12.T_AMg[9] = plgdtm.p51 * hlocal.sh * dkp;
   
     //   function g(l) (additional periodic)
     fp = fp + DTM_12.T_AMg[1] * ddtm_12.T_AMg[1] + DTM_12.T_AMg[2] * ddtm_12.T_AMg[2] 
             + DTM_12.T_AMg[3] * ddtm_12.T_AMg[3] + DTM_12.T_AMg[4] * ddtm_12.T_AMg[4] 
             + DTM_12.T_AMg[5] * ddtm_12.T_AMg[5] + DTM_12.T_AMg[6] * ddtm_12.T_AMg[6] 
             + DTM_12.T_AMg[7] * ddtm_12.T_AMg[7] + DTM_12.T_AMg[8] * ddtm_12.T_AMg[8] 
             + DTM_12.T_AMg[9] * ddtm_12.T_AMg[9];
     //
     dakp = (DTM_12.T_AMg[1] * plgdtm.p10 + DTM_12.T_AMg[2] * plgdtm.p30 + DTM_12.T_AMg[3] * plgdtm.p50) * coste +
            (DTM_12.T_AMg[4] * plgdtm.p11 + DTM_12.T_AMg[5] * plgdtm.p31 + DTM_12.T_AMg[6] * plgdtm.p51) * hlocal.ch + 
            (DTM_12.T_AMg[7] * plgdtm.p11 + DTM_12.T_AMg[8] * plgdtm.p31 + DTM_12.T_AMg[9] * plgdtm.p51) * hlocal.sh;

     ddtm_12.T_kp[5] = ddtm_12.T_kp[5] + dakp * akp[2];
     ddtm_12.T_kp[6] = ddtm_12.T_kp[5] + dakp * c2fi * akp[2];

     //   terms in longitude
     clfl = cos(lon);
     ddtm_12.T_Lon[1] = plgdtm.p11 * clfl;
     ddtm_12.T_Lon[2] = plgdtm.p21 * clfl;
     ddtm_12.T_Lon[3] = plgdtm.p31 * clfl;
     ddtm_12.T_Lon[4] = plgdtm.p41 * clfl;
     ddtm_12.T_Lon[5] = plgdtm.p51 * clfl;
     slfl = sin(lon);
     ddtm_12.T_Lon[6] = plgdtm.p11 * slfl;
     ddtm_12.T_Lon[7] = plgdtm.p21 * slfl;
     ddtm_12.T_Lon[8] = plgdtm.p31 * slfl;
     ddtm_12.T_Lon[9] = plgdtm.p41 * slfl;
     ddtm_12.T_Lon[10] = plgdtm.p51 * slfl;
   
     //   function g(l) periodic (additional)
     for (i = 1; i <=  10; i++ )  //Nb_Lon cdav Nb_Lon is not recording??
         fp = fp + DTM_12.T_Lon[i] * ddtm_12.T_Lon[i];

     //   function g(l) sum (coupled with flux)
     gdel = f0 + fp * f1f;

    } // function gldtm_XX


 
