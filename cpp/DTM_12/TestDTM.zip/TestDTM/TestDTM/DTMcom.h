/*      ----------------------------------------------------------------
*
*                              DTMcom.cpp
*
*  this file contains common routines between the dtm model.
*
*       (w) 719-573-2600, email dvallado@agi.com
*
*     current :
*                6 aug 13  david vallado
*                            conversion to c ++ 
*     changes :
*               10 may 13  sean
*
*     (w) 719-573-2600, email dvallado@agi.com
*
*     *****************************************************************       */

#include <math.h>
#include <io.h>      
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include "stdafx.h"

#include "DTM_12.h"

#pragma once

    //Custom type definitions
    //These types contain all the data which is read directly from input files
    // cdav don't need todaytype as the dtm_daterecordtype does this?
	//typedef struct todaytype
    //{
  	//   int day, month, year, hour, minute, type_flag;
	//   double second;
    //} todaytype;

    //>@brief Structure to store data from solar flux "f" file
    typedef struct f_structtype
	{
        int year;      //< Year
        int month;     //< Month
        int day;       //< Day
        double f;      //< F from file
        double fbar;   //< FBAR from file
	} f_structtype;

    //>@brief Structure to store data from geomagnetic "a" file
    // increment by 1 to have the same indices the same between languages
    typedef struct a_structtype
	{
        int year;      //< Year
        int month;     //< Month
        int day;       //< Day
        int dayofyear; //< Day of year (1-366)
        int mean_am;   //< Mean value of a_m
        int am[9];     //< The eight a_m values in each line of the file
    } a_structtype;
		
    //> @brief Structure to hold the date input by the user
    //>This type allows the user to enter either a MJD2000 date or a day/month/year hh:mm:sec
    //>date, without the need of passing a large number of parameters.
    //>The user must set a type_flag and the required variables
    //>Unused variables do not need to be initialized
    typedef struct dtm_daterectype
	{
       int type_flag;  //<1 for MJD2000 date, 2 for calendar date
       double mjd2000; //< Date in MJD2000
       int day;        //< Day
       int month;      //< Month
       int year;       //< Year
       int hour;       //< Hour
       int minute;     //< Minute
       double second;  //< Seconds
	} dtm_daterectype;

	// store the uncertainty parameters
	typedef struct dtm_unctype
    {
       double nomgrid[25][19], kp_scale[25][19], alt_scale[25][19];
    } dtm_unctype;


		
double a2K
	(  
	   double a
	);

double local_solar_time 
    (
	   double longitude, int hour, int minute, double sec
	);

int leap_day
	(
	   int year
	);

double linear_interpolation 
    (
	    double x1, double y1, double x2, double y2, double x
    );

double  hms2hr 
    (
	    int hr, int mins, double sec
	);

int day_of_year
	(
	    int day, int month, int year
    );

bool mdyhms_ok
    (
	    int day, int month, int year, int hour, int minute,
		double second
    );

void DJ2000
    ( 
	    double MJDay, int& year, int& mon, int& day, int& hr, int& minute, double& sec
	);

void JD2000
    (
	    double& MJDay, int year, int month, int day, int hr, int minute, double sec 
    );

void fatal_error 
	( 
	    int code
	);
 
void warning 
    (
	    int code
    );

void process_input_date 
	( 
	    dtm_daterectype& in_date
    );
     

void InitSPW
    (
	  char path_to_a_file[100], char path_to_f_file[100], int& number_of_lines_in_a_file,
      int& number_of_lines_in_f_file, a_structtype a_indexes[3000], f_structtype f_indexes[3000]
    );

void DTMInit
	(
	  char PATH_TO_DEN_UNC_1[100], char PATH_TO_DEN_UNC_2[100], char PATH_TO_DEN_UNC_3[100],
	  char PATH_TO_DTM2012_IN_FILE[100], char PATH_TO_DTM2012_OUT_FILE[100], int IVERIF,
      double nomgrid[25][19], double kp_scale[25][19], double alt_scale[25][19],
	  pardtmtype& pardtm
    );

void dtm_wrapper
    (
      dtm_daterectype& in_date, double lon, int number_of_lines_in_a_file, int number_of_lines_in_f_file, 
	  a_structtype a_indexes[3000], f_structtype f_indexes[3000],
      double f[3], double fbar[3], double akp[5], double& dayofyear, double& hl
    );

