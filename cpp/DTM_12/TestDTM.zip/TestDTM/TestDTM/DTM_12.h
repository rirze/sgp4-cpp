/*     ----------------------------------------------------------------
*
*                              DTM.h
*
*  this file contains routines for the dtm-2012 atmospheric model
*
*     (w) 719-573-2600, email dvallado@agi.com
*
*     *****************************************************************
*
*     current :
*                6 aug 13  david vallado
*                            conversion to c ++ 
*     changes :
*               10 may 13  sean bruinsma
*                            original baseline
*     *****************************************************************       */

#include <math.h>
#include <io.h>      
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stdafx.h"

#pragma once

   // version :  2012
//   #define pi 3.14159265358979323846 

// cdav increment all by one to start at 1 instead of 0
// create a struct for the numebrs since they don't seem to work as globals in c++
typedef struct dtmindextype
{
	static const int Nb_lat        = 7;
    static const int Nb_flux       = 13;
    static const int Nb_kp         = 16;
    static const int Nb_SLat       = 3;
    static const int Nb_SASLat     = 3;
    static const int Nb_NSLat      = 4;
    static const int Nb_SANSLat    = 4;
    static const int Nb_DiAn       = 13;
    static const int Nb_SDiAn      = 13;
    static const int Nb_TDi        = 3;
    static const int Nb_AMg        = 10;
    static const int Nb_Lon        = 11;
    static const int Nb_dPhas      = 5;
} dtmindextype;

   static const int Nb_lat          = 7;
   static const int Nb_flux         = 13;
   static const int Nb_kp           = 16;
   static const int Nb_SLat         = 3;
   static const int Nb_SASLat       = 3;
   static const int Nb_NSLat        = 4;
   static const int Nb_SANSLat      = 4;
   static const int Nb_DiAn         = 13;
   static const int Nb_SDiAn        = 13;
   static const int Nb_TDi          = 3;
   static const int Nb_AMg          = 10;
   static const int Nb_Lon          = 10;
   static const int Nb_dPhas        = 5;


//   double  DTM_12_T_one;                  //  SUM(T_x * T_dx) except T_dPhas
//   double  DTM_12_T_lat[Nb_lat];          //  in latitude
//   double  DTM_12_T_flux[Nb_flux];        //  in flux
//   double  DTM_12_T_kp[Nb_kp];            //  in kp
//   double  DTM_12_T_SLat[Nb_SLat];        //  annual & symetric in latitude
//   double  DTM_12_T_SASLat[Nb_SASLat];    //  semi-annual & symetric in latitude
//   double  DTM_12_T_NSLat[Nb_NSLat];      //  annual & non-symetric in latitude
//   double  DTM_12_T_SANSLat[Nb_SANSLat];  //  semi-annual  non-symetric in latitude
//   double  DTM_12_T_DiAn[Nb_DiAn];        //  diurnal (& annual coupled)
//   double  DTM_12_T_SDiAn[Nb_SDiAn];      //  semi-diurnal (& annual coupled)
//   double  DTM_12_T_TDi[Nb_TDi];          //  ter-diurnal
//   double  DTM_12_T_AMg[Nb_AMg];          //  activity (Magnetic)
//   double  DTM_12_T_Lon[Nb_Lon];          //  in longitude
//   double  DTM_12_T_dPhas[Nb_dPhas];      //  derivative of phases of the annual and semi-annual terms

typedef struct DTM_12type
  {
	double T_one, T_lat[Nb_lat], T_flux[Nb_flux], T_kp[Nb_kp], T_SLat[Nb_SLat], T_SASLat[Nb_SASLat], 
		   T_NSLat[Nb_NSLat], T_SANSLat[Nb_SANSLat], T_DiAn[Nb_DiAn], T_SDiAn[Nb_SDiAn], T_TDi[Nb_TDi], 
		   T_AMg[Nb_AMg], T_Lon[Nb_Lon], T_dPhas[Nb_dPhas]; 
  } DTM_12type;

//   double  ddtm_12_T_one;                  //  SUM(T_x * T_dx) except T_dPhas
//   double  ddtm_12_T_lat[Nb_lat];          //  in latitude
//   double  ddtm_12_T_flux[Nb_flux];        //  in flux
//   double  ddtm_12_T_kp[Nb_kp];            //  in kp
//   double  ddtm_12_T_SLat[Nb_SLat];        //  annual & symetric in latitude
//   double  ddtm_12_T_SASLat[Nb_SASLat];    //  semi-annual & symetric in latitude
//   double  ddtm_12_T_NSLat[Nb_NSLat];      //  annual & non-symetric in latitude
//   double  ddtm_12_T_SANSLat[Nb_SANSLat];  //  semi-annual  non-symetric in latitude
//   double  ddtm_12_T_DiAn[Nb_DiAn];        //  diurnal (& annual coupled)
//   double  ddtm_12_T_SDiAn[Nb_SDiAn];      //  semi-diurnal (& annual coupled)
//   double  ddtm_12_T_TDi[Nb_TDi];          //  ter-diurnal
//   double  ddtm_12_T_AMg[Nb_AMg];          //  activity (Magnetic)
//   double  ddtm_12_T_Lon[Nb_Lon];          //  in longitude
//   double  ddtm_12_T_dPhas[Nb_dPhas];      //  derivative of phases of the annual and semi-annual terms

typedef struct ddtm_12type
  {
	double T_one, T_lat[Nb_lat], T_flux[Nb_flux], T_kp[Nb_kp], T_SLat[Nb_SLat], T_SASLat[Nb_SASLat], 
		   T_NSLat[Nb_NSLat], T_SANSLat[Nb_SANSLat], T_DiAn[Nb_DiAn], T_SDiAn[Nb_SDiAn], T_TDi[Nb_TDi], 
		   T_AMg[Nb_AMg], T_Lon[Nb_Lon], T_dPhas[Nb_dPhas]; 
  } ddtm_12type;

//.. Common Blocks .. 
typedef struct plgdtmtype
  {
	double p10, p20, p30, p40, p50, p60, p11, p21, p31, p41, p51, p22, p32, p42, p52, 
           p62, p33, p10mg, p20mg, p40mg;
  } plgdtmtype;

typedef struct constype
  {
	double pi, deupi, cdr, sard;
  } constype;

typedef struct datmotype
  {
	int npara, itype, ilin;
  } datmotype;

typedef struct eclipttype
  {
	double cecl, secl, c2ecl, s2ecl, c3ecl, s3ecl, p10ecl, p20ecl, p30ecl, 
           p40ecl, p50ecl, p11ecl, p21ecl, p31ecl, p41ecl, p51ecl, p22ecl, 
           p32ecl, p42ecl, p52ecl, p33ecl;
  } eclipttype;

typedef struct hlocaltype
  {
	double hl0, ch, sh, c2h, s2h, c3h, s3h;
  } hlocaltype;

typedef struct pardtmtype
  {
	 DTM_12type tt, h, he, ox, az2, o2, az, t0, tp;
	 ddtm_12type dtt, dh, dhe, dox, daz2, do2, daz, dt0, dtp;
  }  pardtmtype;


// ---------------- routines ----------------
void dtm2012
    (
	  plgdtmtype& plgdtm, hlocaltype& hlocal, eclipttype& eclipt, datmotype& datmo, constype& cons, pardtmtype& pardtm,
	  double day, double f[3], double fbar[3], double akp[5], double hellp, double hl, double latgd, double lon,
      double& tz, double& tinf, double& tp120, double& ro, double d[7], double& wmm
	);

void density_uncertainty
   ( 
     double nomgrid[25][19], double alt_scale[25][19], double kp_scale[25][19],
	 double hellp, double latgd, double lst, double flux, double kp, 
	 double& unc
   );

void gldtm_XX
	(
	  plgdtmtype& plgdtm, hlocaltype& hlocal, datmotype& datmo, 
	  double f[3], double fbar[3], double akp[5], double day, DTM_12type& DTM_12, ddtm_12type& ddtm_12, 
	  double& gdel, double ff0, double lon
    );
